
import React, { useState } from 'react';
import { MapPin, Phone, Map, Heart, Loader2 } from 'lucide-react';
import { Merchant } from '../types';
import { api } from '../services/api';

interface FacilityCardProps {
  merchant: Merchant;
  productId: string; 
  isDarkMode: boolean;
  onClick?: () => void;
  isWishlisted?: boolean;
  onToggleWishlist?: (id: string) => void;
}

export const FacilityCard: React.FC<FacilityCardProps> = ({ 
  merchant, 
  productId, 
  isDarkMode, 
  onClick,
  isWishlisted = false,
  onToggleWishlist
}) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [isReserving, setIsReserving] = useState(false);
  const [reservationStatus, setReservationStatus] = useState<'idle' | 'success' | 'error'>('idle');
  
  // Use local state to reflect immediate updates if not re-fetched from parent
  const [currentStock, setCurrentStock] = useState(merchant.stock[productId] || 0);

  let stockText = 'Out of Stock';
  let stockColorClass = 'text-red-500';

  if (currentStock > 10) {
    stockText = 'In Stock';
    stockColorClass = 'text-emerald-600';
  } else if (currentStock > 0) {
    stockText = `Low Stock (${currentStock})`;
    stockColorClass = 'text-amber-600';
  }

  const bgClass = isDarkMode ? 'bg-lavender-900/50 border-white/5' : 'bg-white/80 border-gray-100';
  const textMain = isDarkMode ? 'text-white' : 'text-gray-800';
  const textSub = isDarkMode ? 'text-gray-400' : 'text-gray-500';

  const handleHeartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.vibrate) navigator.vibrate(10);
    setIsAnimating(true);
    setTimeout(() => setIsAnimating(false), 300);
    if (onToggleWishlist) onToggleWishlist(merchant.id);
  };

  const handleReserve = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsReserving(true);
    try {
        const success = await api.reserveStock(merchant.id, productId, 1);
        if (success) {
            setReservationStatus('success');
            setCurrentStock(prev => prev - 1);
            setTimeout(() => setReservationStatus('idle'), 2000);
        } else {
            setReservationStatus('error');
            setTimeout(() => setReservationStatus('idle'), 2000);
        }
    } catch (e) {
        setReservationStatus('error');
    } finally {
        setIsReserving(false);
    }
  };

  return (
    <div 
      onClick={onClick}
      className={`p-4 rounded-xl border shadow-sm transition-transform hover:scale-[1.01] cursor-pointer relative group ${bgClass}`}
    >
      <div className="flex justify-between">
        <div className="flex-1">
          <h3 className={`font-semibold text-sm mb-1 ${textMain}`}>{merchant.name}</h3>
          <div className="flex items-center gap-1 mb-2">
            <MapPin size={12} className={textSub} />
            <span className={`text-xs ${textSub}`}>
              {merchant.address} • {merchant.distance}
            </span>
          </div>
          <span className={`text-xs font-bold block ${stockColorClass}`}>
            {stockText}
          </span>
        </div>

        <div className="flex flex-col items-end gap-2 ml-4">
          <button 
            onClick={handleHeartClick}
            className={`p-1.5 rounded-full transition-all duration-300 ${
              isWishlisted 
                ? 'bg-pink-100 text-pink-500 scale-110' 
                : (isDarkMode ? 'text-gray-500 hover:text-pink-400' : 'text-gray-400 hover:text-pink-500')
            } ${isAnimating ? 'animate-bounce' : ''}`}
          >
            <Heart size={16} fill={isWishlisted ? "currentColor" : "none"} />
          </button>

          {currentStock > 0 && (
            <button 
                onClick={handleReserve}
                disabled={isReserving || reservationStatus === 'success'}
                className={`px-3 py-1 text-xs font-medium rounded-full transition-colors flex items-center gap-1 ${
                    reservationStatus === 'success' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                }`}
            >
              {isReserving ? <Loader2 size={12} className="animate-spin"/> : (reservationStatus === 'success' ? 'Reserved' : 'Reserve')}
            </button>
          )}

          <div className="flex gap-2">
            <button className={`p-1.5 rounded-lg border bg-transparent transition-colors ${isDarkMode ? 'text-blue-400 border-blue-400/30' : 'text-blue-600 border-blue-100 hover:bg-blue-50'}`}>
              <Map size={14} />
            </button>
            <button 
              onClick={(e) => { e.stopPropagation(); }}
              className={`p-1.5 rounded-lg border bg-transparent transition-colors ${isDarkMode ? 'text-gray-400 border-white/10' : 'text-gray-50 bg-gray-50 border-transparent hover:text-pink-600'}`}
            >
              <Phone size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
