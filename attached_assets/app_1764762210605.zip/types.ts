
export enum CyclePhase {
  MENSTRUAL = 'Menstrual',
  FOLLICULAR = 'Follicular',
  OVULATION = 'Ovulation',
  LUTEAL = 'Luteal'
}

export interface CycleConfig {
  lastPeriodDate: string; // ISO Date YYYY-MM-DD
  cycleLength: number;
}

export interface CycleData {
  currentDay: number;
  totalLength: number;
  phase: CyclePhase;
  nextPeriodDays: number;
  startDate: string;
}

export interface InspirationContent {
  id: string;
  title: string;
  body: string;
  source?: string;
}

export enum Tab {
  HOME = 'Home',
  CYCLE = 'Cycle',
  SHOP = 'Shop',
  MOM = 'Mom',
  ME = 'Me'
}

export type ProductType = 'Contraceptive' | 'Hygiene' | 'Medicine';

export interface Product {
  id: string;
  name: string;
  description: string;
  type: ProductType;
  price: number;
  tags?: string[]; // Added for Cycle-Synced Shopping
}

export interface CartItem {
  productId: string;
  quantity: number;
  addedAt: number;
}

export interface Merchant {
  id: string;
  name: string;
  address: string;
  distance: string; // e.g., "1.2 km"
  latitude: number;
  longitude: number;
  type: 'Pharmacy' | 'Clinic' | 'Dispenser';
  stock: Record<string, number>; // ProductID -> Count
}

export interface Review {
  id: string;
  merchantId: string;
  userName: string;
  rating: number; // 1-5
  comment: string;
  date: string;
  avatar?: string;
  imageUrl?: string; // Added for Photo Reviews
}

export interface DependentProfile {
  id: string;
  name: string;
  relation: 'Daughter' | 'Sister' | 'Patient' | 'Other';
  avatar?: string;
  age?: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  avatar?: string;
  wishlist?: string[]; // IDs of favorite products/merchants
  recentSearches?: string[];
  
  // Multi-profile support
  activeProfileId?: string; // 'main' or DependentProfile.id
  profiles?: DependentProfile[];
}

export interface LogItem {
  id: string;
  label: string;
  color: string;
}

export interface JournalEntry {
  id: string;
  date: string; // ISO Date String
  content: string;
  tags?: string[];
  _pending?: boolean; // Offline sync flag
}

export interface GeminiRequest {
  prompt: string;
  context?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface CameraAsset {
  id: string;
  dataUrl: string;
  timestamp: number;
  type: 'avatar' | 'prescription';
}

/**
 * State Machine Specification
 * 
 * 1. 'splash': Initial cold boot. 
 *    - Transitions to 'landing' if no token.
 *    - Transitions to 'main' if token exists.
 * 
 * 2. 'landing': Public facing pages.
 *    - Transitions to 'main' on successful login.
 * 
 * 3. 'main': Authenticated app shell.
 *    - Transitions to 'landing' on logout.
 */
export type AppState = 'splash' | 'landing' | 'main';
