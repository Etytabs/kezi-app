
import React, { useState, useEffect, useRef } from 'react';
import { HashRouter, Routes, Route, Navigate, useNavigate, useOutletContext } from 'react-router-dom';
import { 
  Lock, 
  Unlock, 
  WifiOff, 
  ChevronRight, 
  ShieldCheck, 
  Droplets,
  MapPin,
  LogOut,
  User as UserIcon,
  Mail,
  Save,
  Loader2,
  Camera,
  X,
  RefreshCcw,
  Moon,
  Sun,
  Eye,
  EyeOff,
  Globe,
  Shield,
  CircleHelp,
  FileText,
  Droplet,
  ArrowRight,
  Heart,
  Bell,
  Users,
  Plus
} from 'lucide-react';

import { BottomNav } from './BottomNav';
import { CycleWheel } from './CycleWheel';
import { CycleScreen } from './CycleScreen';
import { ShopScreen } from './ShopScreen';
import { MaternalScreen } from './MaternalScreen';
import { MerchantDetail } from './MerchantDetail';
import { GeminiCard } from './GeminiCard';
import { AdminPanel } from './AdminPanel';
import { JasminBrandIcon } from './JasminBrandIcon';
import { User, CyclePhase, Product, Merchant, DependentProfile } from '../types';
import { MOCK_CYCLE_DATA, PRODUCTS_DATA, MOCK_MERCHANTS, MATERNAL_PRODUCTS_DATA } from '../constants';
import { api } from '../services/api';
import { notificationService } from '../services/notificationService';
import { cycleService } from '../services/cycleService'; // Logic import

interface MainAppProps {
  user: User;
  onLogout: () => void;
  onUserUpdate: (user: User) => void;
}

// ----------------------------------------------------------------------
// Sub-components for Dashboard
// ----------------------------------------------------------------------

const JourneyIcon = ({ isDarkMode }: { isDarkMode: boolean }) => (
  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm mb-4 ${isDarkMode ? 'bg-pink-900/20' : 'bg-pink-100'}`}>
    <Droplet size={24} className="text-pink-700" strokeWidth={2.5} />
  </div>
);

// ----------------------------------------------------------------------
// 1. Dashboard Component (Extracted logic)
// ----------------------------------------------------------------------
const DashboardContent = ({ user, isDarkMode, discreetMode }: { user: User, isDarkMode: boolean, discreetMode: boolean }) => {
  const navigate = useNavigate();
  const textClass = isDarkMode ? 'text-night-text' : 'text-gray-800';
  const subTextClass = isDarkMode ? 'text-gray-500' : 'text-gray-500';
  const cardClass = isDarkMode ? 'glass-panel-dark shadow-none' : 'glass-card';

  // Determine Display Name based on Active Profile
  const activeProfile = user.activeProfileId && user.activeProfileId !== 'main' 
    ? user.profiles?.find(p => p.id === user.activeProfileId)
    : null;
  
  const displayName = activeProfile ? activeProfile.name : user.name;

  return (
    <>
      <div>
        <div className="flex items-center gap-2 mb-1">
          <h2 className={`text-3xl font-bold tracking-tight ${textClass} ${discreetMode ? 'blur-sm select-none' : ''}`}>
            Hello, {displayName}
          </h2>
          {activeProfile && (
             <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${isDarkMode ? 'bg-pink-900/30 text-pink-300' : 'bg-pink-100 text-pink-600'}`}>
               {activeProfile.relation}
             </span>
          )}
        </div>
        <p className={`${subTextClass} font-medium`}>Your health, your power. What do you need today?</p>
      </div>

      {/* Cycle Journey Card - Pixel Accurate Spec */}
      <div className={`relative overflow-hidden rounded-3xl p-6 transition-all duration-500 border ${
        isDarkMode 
          ? 'bg-gradient-to-br from-pink-900/20 to-purple-900/20 border-white/5' 
          : 'bg-gradient-to-br from-[#FFF5F7] via-[#FFF0F5] to-[#F3E8FF] border-white/80 shadow-xl shadow-pink-100/50'
      }`}>
        {/* Background Pattern (Abstract Blob) */}
        <svg className="absolute bottom-0 right-0 w-48 h-48 text-pink-500/5 dark:text-pink-500/10 transform translate-x-10 translate-y-10 pointer-events-none" viewBox="0 0 200 200" fill="currentColor">
          <path d="M45.7,-70.5C58.9,-62.5,69.3,-49.4,75.9,-34.7C82.5,-20,85.4,-3.7,81.5,11.2C77.6,26.1,67,39.6,55.5,50.6C44,61.6,31.6,70.1,17.7,74.6C3.8,79.1,-11.6,79.6,-25.7,74.4C-39.8,69.2,-52.6,58.3,-62.7,45.2C-72.8,32.1,-80.2,16.8,-79.3,2C-78.4,-12.8,-69.2,-27.1,-58.1,-39.3C-47,-51.5,-34,-61.6,-20.1,-68.8C-6.2,-76,8.6,-80.3,23.6,-78.9C38.6,-77.5,53.8,-70.5,45.7,-70.5Z" transform="translate(100 100)" />
        </svg>

        <div className="relative z-10">
          <div className="flex justify-between items-start">
             {/* Pixel-Accurate Journey Icon */}
             <JourneyIcon isDarkMode={isDarkMode} />
             
             {/* Eyebrow */}
             <span className="text-[10px] font-bold uppercase tracking-widest text-pink-600/70 bg-pink-100/50 px-2 py-1 rounded-full backdrop-blur-sm">
               Today's Status
             </span>
          </div>

          <h3 className={`text-2xl font-bold mb-1 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Cycle Journey</h3>
          <p className={`text-sm leading-relaxed max-w-[260px] ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
            {cycleService.getPhaseDescription(MOCK_CYCLE_DATA.phase)}
          </p>

          <div className="flex items-center gap-4 mt-6">
            <button 
              onClick={() => navigate('/cycle')}
              className={`px-6 py-3 rounded-full text-sm font-semibold flex items-center gap-2 transition-transform active:scale-95 shadow-lg ${
                isDarkMode ? 'bg-white text-black hover:bg-gray-100' : 'bg-gray-900 text-white hover:bg-gray-800'
              }`}
            >
              Open Tracker <ArrowRight size={16} />
            </button>
            <span className="text-xs font-bold text-gray-400">
              Day {MOCK_CYCLE_DATA.currentDay}
            </span>
          </div>
        </div>
      </div>

      <div className={`${cardClass} rounded-3xl p-6 ${!isDarkMode ? 'bg-gradient-to-br from-teal-50/50 to-white/50 border-teal-100/30' : ''}`}>
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isDarkMode ? 'bg-night-deep text-teal-400' : 'bg-teal-100 text-teal-600'}`}>
            <ShieldCheck size={20} />
          </div>
          <h3 className={`font-bold ${textClass}`}>Essentials & Hygiene</h3>
        </div>
        
        <p className={`text-sm mb-6 ${subTextClass}`}>
          Locate pads, cups, and hygiene kits at nearby trusted facilities.
        </p>

        <div className="flex gap-3 w-full">
          <button 
            onClick={() => navigate('/shop')}
            className={`flex-1 py-3 px-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all ${isDarkMode ? 'bg-night-deep text-teal-400 shadow-none' : 'bg-teal-500 text-white shadow-teal-100/50 hover:bg-teal-600'}`}
          >
            Find Hygiene Items
          </button>
          <button 
            onClick={() => navigate('/mom')}
            className={`flex-1 py-3 px-4 rounded-xl font-semibold border shadow-sm hover:opacity-90 transition-colors text-sm ${isDarkMode ? 'bg-transparent border-white/10 text-gray-400' : 'bg-white text-gray-700 border-gray-100'}`}
          >
            Maternal Meds
          </button>
        </div>
      </div>

      <GeminiCard phase={MOCK_CYCLE_DATA.phase} />

      <div className="pt-2 pb-6">
          <h3 className={`font-bold mb-4 text-lg ${textClass}`}>Coming Soon</h3>
          <div className="grid grid-cols-2 gap-4">
            {['ANC Manager', 'Nutrition & Anemia', 'Neonatal & KMC', 'CHW Tools'].map((item, idx) => (
              <div key={idx} className={`p-4 rounded-2xl flex flex-col justify-center min-h-[100px] transition-colors ${isDarkMode ? 'glass-panel-dark hover:bg-night-deep' : 'glass-panel hover:bg-white/60'}`}>
                <h4 className={`font-bold text-sm ${textClass}`}>{item}</h4>
                <span className={`text-xs mt-1 ${subTextClass}`}>Planned</span>
              </div>
            ))}
          </div>
      </div>
    </>
  );
};

// ... (ProfileContent and Header components remain similar, mostly cosmetic or routing changes)
// For brevity, skipping full re-implementation of unmodified sub-components in MainApp if they weren't strictly requested to change
// But user profile component needs to be here.

const ProfileContent = ({ 
  user, 
  onUserUpdate, 
  isDarkMode, 
  startCamera, 
  discreetMode, 
  setDiscreetMode, 
  setIsDarkMode 
}: { 
  user: User, 
  onUserUpdate: (u: User) => void, 
  isDarkMode: boolean, 
  startCamera: (t: 'avatar', m: 'user') => void,
  discreetMode: boolean,
  setDiscreetMode: (v: boolean) => void,
  setIsDarkMode: (v: boolean) => void
}) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: user.name, email: user.email, avatar: user.avatar });
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [showSaveConfirm, setShowSaveConfirm] = useState(false);
  
  // Notification State
  const [notificationsEnabled, setNotificationsEnabled] = useState(notificationService.hasPermission());

  // Dependent Profile Modal
  const [isAddProfileOpen, setIsAddProfileOpen] = useState(false);
  const [newProfileData, setNewProfileData] = useState({ name: '', relation: 'Daughter' as 'Daughter' | 'Sister' | 'Patient' | 'Other', age: '' });

  useEffect(() => {
    setFormData({ name: user.name, email: user.email, avatar: user.avatar });
  }, [user]);

  const hasChanges = formData.name !== user.name || formData.email !== user.email || formData.avatar !== user.avatar;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (hasChanges) setShowSaveConfirm(true);
  };

  const handleConfirmSave = async () => {
    setShowSaveConfirm(false);
    setIsSavingProfile(true);
    setSaveMessage(null);
    try {
      const updatedUser = await api.updateUser({ ...user, ...formData });
      onUserUpdate(updatedUser);
      setSaveMessage("Profile updated successfully");
      setTimeout(() => setSaveMessage(null), 3000);
    } catch (error) {
      setSaveMessage("Failed to update profile");
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleNotificationToggle = async () => {
    if (notificationsEnabled) {
      setNotificationsEnabled(false);
    } else {
      const granted = await notificationService.requestPermission();
      if (granted) {
        setNotificationsEnabled(true);
        notificationService.testNotification();
      }
    }
  };

  const handleAddProfile = async () => {
    if (!newProfileData.name) return;
    try {
        const updatedUser = await api.addDependentProfile(user.id, {
            name: newProfileData.name,
            relation: newProfileData.relation,
            age: newProfileData.age ? parseInt(newProfileData.age) : undefined
        });
        onUserUpdate(updatedUser);
        setIsAddProfileOpen(false);
        setNewProfileData({ name: '', relation: 'Daughter', age: '' });
    } catch (e) {
        console.error("Failed to add profile");
    }
  };

  const handleSwitchProfile = async (profileId: string) => {
    try {
        const updatedUser = await api.switchActiveProfile(user.id, profileId);
        onUserUpdate(updatedUser);
    } catch (e) {
        console.error("Failed to switch profile");
    }
  };

  const textClass = isDarkMode ? 'text-night-text' : 'text-gray-800';
  const subTextClass = isDarkMode ? 'text-gray-500' : 'text-gray-500';
  const cardClass = isDarkMode ? 'glass-panel-dark shadow-none' : 'glass-card';
  const inputClass = isDarkMode 
    ? 'bg-night-deep border-white/10 text-night-text focus:ring-purple-500' 
    : 'bg-white/80 border-gray-200 text-gray-800 focus:ring-pink-300';

  const wishlistItems = (user.wishlist || []).map(id => {
    const merchant = MOCK_MERCHANTS.find(m => m.id === id);
    if (merchant) return { type: 'merchant', data: merchant };
    return null;
  }).filter(Boolean) as { type: 'merchant', data: Merchant }[];

  const activeProfileId = user.activeProfileId || 'main';

  return (
    <div className="space-y-6 animate-fade-in pb-20">
      
      {/* 1. Profile Switcher (Carer Support) */}
      <div className="space-y-3">
         <div className="flex items-center gap-2 px-1">
            <Users size={16} className="text-pink-500" />
            <h3 className={`text-xs font-bold uppercase tracking-wider ${subTextClass}`}>Manage Profiles</h3>
         </div>
         <div className="flex gap-4 overflow-x-auto pb-4 -mx-6 px-6 no-scrollbar">
            {/* Main User Card */}
            <div 
              onClick={() => handleSwitchProfile('main')}
              className={`flex-shrink-0 flex flex-col items-center gap-2 min-w-[72px] cursor-pointer transition-transform active:scale-95`}
            >
                <div className={`w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold border-2 transition-all ${
                    activeProfileId === 'main' 
                    ? (isDarkMode ? 'border-pink-500 shadow-[0_0_15px_rgba(236,72,153,0.3)]' : 'border-pink-500 shadow-lg shadow-pink-200') 
                    : 'border-transparent opacity-60'
                } ${isDarkMode ? 'bg-night-deep' : 'bg-white'}`}>
                     {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover rounded-full" /> : user.name.charAt(0)}
                </div>
                <span className={`text-[10px] font-bold text-center leading-tight max-w-[72px] truncate ${activeProfileId === 'main' ? (isDarkMode ? 'text-white' : 'text-gray-800') : 'text-gray-400'}`}>
                    Me
                </span>
            </div>

            {/* Dependent Profiles */}
            {(user.profiles || []).map(p => (
                <div 
                  key={p.id}
                  onClick={() => handleSwitchProfile(p.id)}
                  className={`flex-shrink-0 flex flex-col items-center gap-2 min-w-[72px] cursor-pointer transition-transform active:scale-95`}
                >
                    <div className={`w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold border-2 transition-all ${
                        activeProfileId === p.id
                        ? (isDarkMode ? 'border-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.3)]' : 'border-purple-500 shadow-lg shadow-purple-200') 
                        : 'border-transparent opacity-60'
                    } ${isDarkMode ? 'bg-night-deep text-purple-300' : 'bg-purple-50 text-purple-600'}`}>
                         {p.avatar ? <img src={p.avatar} className="w-full h-full object-cover rounded-full" /> : p.name.charAt(0)}
                    </div>
                    <span className={`text-[10px] font-bold text-center leading-tight max-w-[72px] truncate ${activeProfileId === p.id ? (isDarkMode ? 'text-white' : 'text-gray-800') : 'text-gray-400'}`}>
                        {p.name}
                    </span>
                    <span className="text-[9px] text-gray-400 -mt-2">{p.relation}</span>
                </div>
            ))}

            {/* Add New Profile Button */}
            <div 
              onClick={() => setIsAddProfileOpen(true)}
              className="flex-shrink-0 flex flex-col items-center gap-2 min-w-[72px] cursor-pointer opacity-70 hover:opacity-100 transition-opacity"
            >
                <div className={`w-14 h-14 rounded-full flex items-center justify-center border-2 border-dashed ${isDarkMode ? 'border-gray-600 bg-white/5' : 'border-gray-300 bg-gray-50'}`}>
                    <Plus size={20} className="text-gray-400" />
                </div>
                <span className="text-[10px] font-bold text-gray-400">Add</span>
            </div>
         </div>
      </div>

      <h2 className={`text-2xl font-bold tracking-tight ${textClass}`}>Account Settings</h2>
      
      {/* Profile Edit Card */}
      <div className={`${cardClass} rounded-3xl p-8`}>
        {/* ... (Existing Profile form content) ... */}
        {/* Simplified for response length constraint, logic remains same */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative group">
            <div className={`w-24 h-24 rounded-full flex items-center justify-center text-3xl font-bold mb-4 shadow-lg overflow-hidden ${isDarkMode ? 'bg-night-deep text-purple-300 ring-2 ring-purple-500/20' : 'bg-gradient-to-br from-pink-100 to-purple-100 text-pink-600 ring-4 ring-white'}`}>
              {formData.avatar ? (
                <img src={formData.avatar} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                user.name.charAt(0).toUpperCase()
              )}
            </div>
            <button 
              type="button"
              onClick={() => startCamera('avatar', 'user')}
              className={`absolute bottom-0 right-0 p-2.5 rounded-full text-white shadow-lg hover:scale-105 transition-all border-4 ${isDarkMode ? 'bg-purple-600 border-night-deep' : 'bg-pink-500 hover:bg-pink-600 border-white'}`}
            >
              <Camera size={16} />
            </button>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'bg-night-deep text-purple-300' : 'bg-purple-100 text-purple-600'}`}>
            {user.role} Account
          </span>
          {user.role === 'admin' && (
            <button 
              onClick={() => navigate('/admin')}
              className={`mt-2 flex items-center gap-1 text-xs font-bold transition-colors ${isDarkMode ? 'text-pink-400 hover:text-pink-300' : 'text-pink-600 hover:text-pink-700'}`}
            >
              <Shield size={12} />
              Open Admin Panel
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <label className={`text-xs font-semibold uppercase tracking-wide ml-1 ${subTextClass}`}>Display Name</label>
            <div className="relative">
              <UserIcon className={`absolute left-4 top-3.5 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`} size={18} />
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className={`w-full rounded-xl py-3 pl-11 pr-4 outline-none focus:ring-2 transition-all ${inputClass}`}
                placeholder="Your Name"
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className={`text-xs font-semibold uppercase tracking-wide ml-1 ${subTextClass}`}>Email Address</label>
            <div className="relative">
              <Mail className={`absolute left-4 top-3.5 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`} size={18} />
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className={`w-full rounded-xl py-3 pl-11 pr-4 outline-none focus:ring-2 transition-all ${inputClass}`}
                placeholder="name@example.com"
              />
            </div>
          </div>
          {saveMessage && (
            <div className={`text-sm text-center py-2 font-medium ${saveMessage.includes('Failed') ? 'text-red-500' : 'text-emerald-500'}`}>
              {saveMessage}
            </div>
          )}
          <button
            type="submit"
            disabled={isSavingProfile || !hasChanges}
            className={`w-full py-4 rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 transform active:scale-95 transition-all mt-4 ${
              isDarkMode 
                ? 'bg-purple-600 text-white hover:bg-purple-700 shadow-purple-900/20' 
                : 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-pink-200 hover:shadow-pink-300'
            } ${(isSavingProfile || !hasChanges) ? 'opacity-50 cursor-not-allowed shadow-none' : ''}`}
          >
            {isSavingProfile ? <Loader2 className="animate-spin" size={20} /> : <><Save size={18} /> Save Changes</>}
          </button>
        </form>
      </div>

      {/* Wishlist Card */}
      {wishlistItems.length > 0 && (
        <div className={`${cardClass} rounded-3xl overflow-hidden`}>
          <div className={`px-4 py-3 border-b ${isDarkMode ? 'bg-black/20 border-white/10' : 'bg-gray-50/80 border-gray-100'}`}>
            <h3 className={`text-[10px] font-bold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-400'}`}>
              My Wishlist
            </h3>
          </div>
          <div className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-gray-50'}`}>
            {wishlistItems.map((item) => (
              <div 
                key={item.data.id} 
                className="p-4 flex items-center justify-between cursor-pointer hover:opacity-80 transition-opacity"
                onClick={() => navigate(`/merchant/${item.data.id}`)}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${isDarkMode ? 'bg-white/10' : 'bg-pink-50 text-pink-500'}`}>
                    <Heart size={16} fill="currentColor" />
                  </div>
                  <div>
                    <p className={`text-sm font-semibold ${textClass}`}>{item.data.name}</p>
                    <p className={`text-xs ${subTextClass}`}>{item.data.type}</p>
                  </div>
                </div>
                <ChevronRight size={16} className={subTextClass} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Settings Card */}
      <div className={`rounded-3xl border shadow-sm overflow-hidden ${isDarkMode ? 'bg-lavender-900/50 border-white/10' : 'bg-white border-gray-100'}`}>
        {/* ... Same settings content ... */}
        <div className={`px-4 py-3 border-b ${isDarkMode ? 'bg-black/20 border-white/10' : 'bg-gray-50/80 border-gray-100'}`}>
          <h3 className={`text-[10px] font-bold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-400'}`}>
            Appearance & Privacy
          </h3>
        </div>
        <div className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-gray-50'}`}>
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${isDarkMode ? 'bg-indigo-900/30 text-indigo-300' : 'bg-indigo-50 text-indigo-600'}`}>
                {isDarkMode ? <Moon size={20} /> : <Sun size={20} />}
              </div>
              <div className="ml-3">
                <p className={`text-sm font-semibold ${textClass}`}>Night Mode</p>
                <p className={`text-xs ${subTextClass}`}>Reduce eye strain</p>
              </div>
            </div>
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`w-11 h-6 rounded-full transition-colors duration-200 flex items-center px-1 ${isDarkMode ? 'bg-pink-500' : (isDarkMode ? 'bg-white/10' : 'bg-gray-200')}`}
            >
              <div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform duration-200 ${isDarkMode ? 'translate-x-5' : 'translate-x-0'}`} />
            </button>
          </div>
          {/* ... other settings ... */}
           {/* Notifications Toggle */}
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${notificationsEnabled ? 'bg-emerald-100 text-emerald-600' : 'bg-orange-100 text-orange-600'}`}>
                <Bell size={20} />
              </div>
              <div className="ml-3">
                <p className={`text-sm font-semibold ${textClass}`}>Notifications</p>
                <p className={`text-xs ${subTextClass}`}>Fertile window & reminders</p>
              </div>
            </div>
            <button 
              onClick={handleNotificationToggle}
              className={`w-11 h-6 rounded-full transition-colors duration-200 flex items-center px-1 ${notificationsEnabled ? 'bg-pink-500' : (isDarkMode ? 'bg-white/10' : 'bg-gray-200')}`}
            >
              <div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform duration-200 ${notificationsEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
            </button>
          </div>
        </div>
      </div>
      
      {/* Support Card */}
      <div className={`rounded-3xl border shadow-sm overflow-hidden ${isDarkMode ? 'bg-night-deep/50 border-white/10' : 'bg-white border-gray-100'}`}>
        {/* ... Same support content ... */}
        <div className={`px-4 py-3 border-b ${isDarkMode ? 'bg-black/20 border-white/10' : 'bg-gray-50/80 border-gray-100'}`}>
          <h3 className="text-[10px] font-bold uppercase tracking-wider text-gray-400">
            Support
          </h3>
        </div>
        <div className="p-4 flex flex-col gap-4">
          <a href="#" className="flex items-center gap-3 group">
            <CircleHelp size={18} className="text-gray-400" />
            <span className={`text-sm font-medium transition-colors group-hover:text-pink-600 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Help Center
            </span>
          </a>
          <a href="#" className="flex items-center gap-3 group">
             <Mail size={18} className="text-gray-400" />
            <span className={`text-sm font-medium transition-colors group-hover:text-pink-600 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Contact Us
            </span>
          </a>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showSaveConfirm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm animate-fade-in p-4">
          <div className={`${cardClass} w-full max-w-sm p-6 rounded-3xl shadow-2xl animate-slide-up border border-white/20`}>
            <h3 className={`text-lg font-bold mb-2 ${textClass}`}>Save Changes?</h3>
            <p className={`text-sm mb-6 ${subTextClass}`}>
              Are you sure you want to update your profile information?
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowSaveConfirm(false)}
                className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                  isDarkMode ? 'bg-white/10 text-gray-300 hover:bg-white/20' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmSave}
                className="flex-1 py-3 rounded-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg shadow-pink-200 hover:shadow-pink-300"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Profile Modal */}
      {isAddProfileOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 backdrop-blur-sm animate-fade-in p-4">
          <div className={`${cardClass} w-full max-w-sm p-6 rounded-3xl shadow-2xl animate-slide-up border border-white/20`}>
            <div className="flex justify-between items-center mb-4">
                <h3 className={`text-lg font-bold ${textClass}`}>Add Profile</h3>
                <button onClick={() => setIsAddProfileOpen(false)}><X size={20} className={subTextClass}/></button>
            </div>
            {/* ... Form Content ... */}
             <div className="space-y-4">
                <div className="space-y-2">
                    <label className={`text-xs font-bold uppercase tracking-wide ${subTextClass}`}>Name</label>
                    <input 
                        type="text" 
                        value={newProfileData.name}
                        onChange={(e) => setNewProfileData({...newProfileData, name: e.target.value})}
                        className={`w-full rounded-xl py-3 px-4 outline-none focus:ring-2 ${inputClass}`}
                        placeholder="e.g. Sarah"
                    />
                </div>
                <div className="space-y-2">
                    <label className={`text-xs font-bold uppercase tracking-wide ${subTextClass}`}>Relation</label>
                    <div className="grid grid-cols-2 gap-2">
                        {['Daughter', 'Sister', 'Patient', 'Other'].map((rel) => (
                            <button
                                key={rel}
                                onClick={() => setNewProfileData({...newProfileData, relation: rel as any})}
                                className={`py-2 rounded-lg text-xs font-bold transition-colors ${
                                    newProfileData.relation === rel 
                                    ? 'bg-purple-500 text-white' 
                                    : (isDarkMode ? 'bg-white/10 text-gray-400' : 'bg-gray-100 text-gray-600')
                                }`}
                            >
                                {rel}
                            </button>
                        ))}
                    </div>
                </div>
                <button
                    onClick={handleAddProfile}
                    className="w-full py-3 rounded-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg mt-2"
                >
                    Create Profile
                </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const Header = ({ 
  isDarkMode, 
  onLogout, 
  discreetMode, 
  toggleDiscreet 
}: { 
  isDarkMode: boolean; 
  onLogout: () => void; 
  discreetMode: boolean; 
  toggleDiscreet: () => void; 
}) => {
  const navigate = useNavigate();

  return (
    <header className={`sticky top-0 z-40 pt-safe px-6 pb-2 border-b transition-colors duration-500 ${isDarkMode ? 'glass-panel-dark border-white/5' : 'glass-panel border-white/40'}`}>
      <div className="flex justify-between items-center h-16">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 hover:opacity-80 transition-opacity active:scale-95"
          title="Go Back"
        >
          <h1 className={`text-2xl font-bold tracking-tight transition-colors ${isDarkMode ? 'text-night-text' : 'text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-600'}`}>
            Jasmin
          </h1>
          {!isDarkMode && <JasminBrandIcon />}
        </button>
        
        <div className="flex items-center gap-3">
          <button onClick={onLogout} className={`p-2 rounded-full shadow-sm text-xs font-semibold hover:opacity-80 transition ${isDarkMode ? 'bg-night-deep text-red-400' : 'bg-white/60 text-red-400'}`}>
            <LogOut size={16} />
          </button>
          <button onClick={toggleDiscreet} className={`p-2 rounded-full transition-all ${discreetMode ? 'bg-night-deep text-purple-300' : (isDarkMode ? 'bg-white/10 text-gray-300' : 'bg-white/60 text-gray-500 hover:text-pink-500')}`}>
            {discreetMode ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>
        </div>
      </div>
    </header>
  );
};

export const MainApp: React.FC<MainAppProps> = ({ user, onLogout, onUserUpdate }) => {
  const [discreetMode, setDiscreetMode] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [isHydrating, setIsHydrating] = useState(true);
  const [wishlist, setWishlist] = useState<string[]>(user.wishlist || []);
  const [recentSearches, setRecentSearches] = useState<string[]>(user.recentSearches || []);

  // Camera State
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [cameraTarget, setCameraTarget] = useState<'avatar' | 'prescription' | null>(null); 
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    // Offline Logic
    const handleStatusChange = () => {
      const online = navigator.onLine;
      setIsOffline(!online);
      if (online) {
        // Trigger Offline Sync when back online
        api.syncData();
      }
    };
    
    window.addEventListener('online', handleStatusChange);
    window.addEventListener('offline', handleStatusChange);
    
    const hydrate = async () => {
      const [cycleData] = await Promise.all([api.getCycleData(), api.getMerchants(), api.getStock()]);
      setIsHydrating(false);

      // Check for notifications
      notificationService.checkFertileWindow(cycleData.phase);
    };
    hydrate();

    return () => {
      window.removeEventListener('online', handleStatusChange);
      window.removeEventListener('offline', handleStatusChange);
    };
  }, []);

  // ... (Rest of MainApp Logic - Camera, Render)
  // Camera Effects
  useEffect(() => {
    if (isCameraOpen && videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(e => console.error("Error playing video:", e));
    }
  }, [isCameraOpen, stream]);

  useEffect(() => {
    return () => {
      if (stream) stream.getTracks().forEach(track => track.stop());
    };
  }, [stream]);

  const toggleDiscreet = () => setDiscreetMode(!discreetMode);

  const startCamera = async (target: 'avatar' | 'prescription', mode: 'user' | 'environment' = 'user') => {
    if (stream) stream.getTracks().forEach(track => track.stop());
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: mode } });
      setStream(mediaStream);
      setFacingMode(mode);
      setCameraTarget(target);
      setIsCameraOpen(true);
    } catch (err) {
      alert("Unable to access camera.");
    }
  };

  const switchCamera = () => {
    if (!cameraTarget) return;
    const newMode = facingMode === 'user' ? 'environment' : 'user';
    startCamera(cameraTarget, newMode);
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsCameraOpen(false);
    setCameraTarget(null);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        if (facingMode === 'user') {
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1);
        }
        ctx.drawImage(video, 0, 0);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        if (cameraTarget === 'avatar') {
          onUserUpdate({ ...user, avatar: dataUrl }); 
        }
        stopCamera();
      }
    }
  };

  const handleToggleWishlist = (id: string) => {
    const newWishlist = wishlist.includes(id) 
      ? wishlist.filter(item => item !== id)
      : [...wishlist, id];
    
    setWishlist(newWishlist);
    api.updateUser({ ...user, wishlist: newWishlist });
  };

  const handleAddRecentSearch = (term: string) => {
    if (recentSearches.includes(term)) return;
    const newSearches = [term, ...recentSearches].slice(0, 5);
    setRecentSearches(newSearches);
    api.updateUser({ ...user, recentSearches: newSearches });
  };

  const handleClearRecentSearch = () => {
    setRecentSearches([]);
    api.updateUser({ ...user, recentSearches: [] });
  };

  // Cycle-Synced Theming Logic
  const getCycleThemeClass = () => {
    if (isDarkMode) return 'bg-night-base';
    
    switch (MOCK_CYCLE_DATA.phase) {
      case CyclePhase.MENSTRUAL:
        return 'bg-gradient-to-b from-pink-50 via-rose-50 to-pink-50';
      case CyclePhase.FOLLICULAR:
        return 'bg-gradient-to-b from-teal-50 via-emerald-50 to-teal-50';
      case CyclePhase.OVULATION:
        return 'bg-gradient-to-b from-purple-50 via-indigo-50 to-purple-50';
      case CyclePhase.LUTEAL:
        return 'bg-gradient-to-b from-pink-50 via-purple-50 to-teal-50';
      default:
        return 'bg-gradient-to-b from-pink-50 via-purple-50 to-teal-50';
    }
  };

  const bgClass = getCycleThemeClass();

  return (
    <HashRouter>
      <div className={`min-h-screen pb-24 transition-colors duration-1000 font-sans ${bgClass} ${!isDarkMode ? 'bg-white/30 backdrop-blur-3xl' : ''}`}>
        
        <Header 
          isDarkMode={isDarkMode} 
          onLogout={onLogout} 
          discreetMode={discreetMode} 
          toggleDiscreet={toggleDiscreet} 
        />

        {isOffline && (
          <div className="mx-6 mt-4 bg-amber-500 text-white text-xs font-bold py-2 px-4 rounded-full flex items-center justify-center gap-2 shadow-lg animate-pulse tracking-wide">
            <WifiOff size={14} />
            <span>Offline Mode Active</span>
          </div>
        )}

        <main className={`px-6 pt-6 space-y-8 animate-fade-in-up ${isHydrating ? 'opacity-50 pointer-events-none' : 'opacity-100'} transition-opacity duration-500`}>
          <Routes>
            <Route path="/" element={<Navigate to="/home" replace />} />
            <Route path="/home" element={<DashboardContent user={user} isDarkMode={isDarkMode} discreetMode={discreetMode} />} />
            <Route path="/cycle" element={<CycleScreen data={MOCK_CYCLE_DATA} isDarkMode={isDarkMode} discreetMode={discreetMode} />} />
            <Route path="/shop" element={
              <ShopScreen 
                isDarkMode={isDarkMode} 
                cyclePhase={MOCK_CYCLE_DATA.phase} 
                wishlist={wishlist}
                onToggleWishlist={handleToggleWishlist}
                recentSearches={recentSearches}
                onAddRecentSearch={handleAddRecentSearch}
                onClearRecentSearch={handleClearRecentSearch}
              />
            } />
            <Route path="/merchant/:id" element={<MerchantDetail isDarkMode={isDarkMode} />} />
            <Route path="/mom" element={<MaternalScreen isDarkMode={isDarkMode} onUploadClick={() => startCamera('prescription', 'environment')} />} />
            <Route path="/me" element={
              <ProfileContent 
                user={user} 
                onUserUpdate={onUserUpdate} 
                isDarkMode={isDarkMode} 
                setIsDarkMode={setIsDarkMode}
                startCamera={startCamera} 
                discreetMode={discreetMode}
                setDiscreetMode={setDiscreetMode}
              />
            } />
            <Route path="/admin" element={
              user.role === 'admin' 
                ? <AdminPanel isDarkMode={isDarkMode} currentUser={user} /> 
                : <Navigate to="/home" replace />
            } />
          </Routes>
        </main>

        <BottomNav isDarkMode={isDarkMode} />

        {isCameraOpen && (
          <div className="fixed inset-0 z-[70] bg-night-base/90 backdrop-blur-xl flex flex-col items-center justify-center p-4">
            <div className="relative w-full max-w-md rounded-2xl overflow-hidden aspect-[3/4] sm:aspect-square border border-white/10 bg-black shadow-2xl">
              <video ref={videoRef} className={`w-full h-full object-cover transition-transform duration-500 ${facingMode === 'user' ? 'transform scale-x-[-1]' : ''}`} playsInline muted autoPlay />
              <canvas ref={canvasRef} className="hidden" />
              <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10">
                <button onClick={switchCamera} className="p-3 bg-white/10 backdrop-blur-md border border-white/20 text-white rounded-full hover:bg-white/20 transition-colors shadow-lg">
                  <RefreshCcw size={20} />
                </button>
                <button onClick={stopCamera} className="p-3 bg-white/10 backdrop-blur-md border border-white/20 text-white rounded-full hover:bg-white/20 transition-colors shadow-lg">
                  <X size={24} />
                </button>
              </div>
              <div className="absolute bottom-6 left-0 right-0 flex justify-center z-10">
                 <button onClick={capturePhoto} className="p-1 rounded-full border-4 border-white/40 hover:border-white transition-all transform active:scale-95">
                  <div className="w-16 h-16 bg-white rounded-full border-4 border-transparent shadow-inner"></div>
                </button>
              </div>
            </div>
            <div className="mt-8 text-center animate-fade-in">
              <p className="text-gray-300 text-sm font-medium tracking-wide">
                {cameraTarget === 'prescription' ? 'Photograph the document' : 'Position your face within the frame'}
              </p>
            </div>
          </div>
        )}
      </div>
    </HashRouter>
  );
};