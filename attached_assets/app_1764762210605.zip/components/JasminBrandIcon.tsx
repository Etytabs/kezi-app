import React from 'react';

export const JasminBrandIcon = ({ className = "animate-spin-slow" }: { className?: string }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
    width="28"
    height="28"
    className={className}
  >
    <g transform="translate(12,12)">
      {/* Petal 1: 0 deg */}
      <path d="M0 0 C-2.5 -5 -4.5 -9 0 -11 C4.5 -9 2.5 -5 0 0" fill="#FDE047" stroke="#FACC15" strokeWidth="0.5" />
      
      {/* Petal 2: 72 deg */}
      <path d="M0 0 C-2.5 -5 -4.5 -9 0 -11 C4.5 -9 2.5 -5 0 0" fill="#FDE047" stroke="#FACC15" strokeWidth="0.5" transform="rotate(72)" />
      
      {/* Petal 3: 144 deg */}
      <path d="M0 0 C-2.5 -5 -4.5 -9 0 -11 C4.5 -9 2.5 -5 0 0" fill="#FDE047" stroke="#FACC15" strokeWidth="0.5" transform="rotate(144)" />
      
      {/* Petal 4: 216 deg */}
      <path d="M0 0 C-2.5 -5 -4.5 -9 0 -11 C4.5 -9 2.5 -5 0 0" fill="#FDE047" stroke="#FACC15" strokeWidth="0.5" transform="rotate(216)" />
      
      {/* Petal 5: 288 deg */}
      <path d="M0 0 C-2.5 -5 -4.5 -9 0 -11 C4.5 -9 2.5 -5 0 0" fill="#FDE047" stroke="#FACC15" strokeWidth="0.5" transform="rotate(288)" />

      {/* Center Base */}
      <circle cx="0" cy="0" r="2.5" fill="#D97706" />
      
      {/* Center Core */}
      <circle cx="0" cy="0" r="1.5" fill="#F59E0B" />
      
      {/* Highlight */}
      <circle cx="0.8" cy="-0.8" r="0.5" fill="#FEF3C7" opacity="0.8" />
    </g>
  </svg>
);
