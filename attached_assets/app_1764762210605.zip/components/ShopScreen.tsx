
import React, { useState, useEffect, useRef } from 'react';
import { Search, ChevronRight, ArrowLeft, Sprout, Map as MapIcon, List, Filter, Clock, X, RefreshCw, Navigation } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { FacilityCard } from './FacilityCard';
import { Product, ProductType, CyclePhase, Merchant } from '../types';
import { PRODUCTS_DATA, MOCK_MERCHANTS } from '../constants';
import { ProductSkeleton, FacilitySkeleton } from './SkeletonLoader';
import { GentleMap } from './GentleMap';
import { api } from '../services/api';

interface ShopScreenProps {
  isDarkMode: boolean;
  cyclePhase?: CyclePhase;
  wishlist?: string[];
  onToggleWishlist?: (id: string) => void;
  recentSearches?: string[];
  onAddRecentSearch?: (term: string) => void;
  onClearRecentSearch?: () => void;
}

type SortOption = 'Distance' | 'Price';
type FilterType = 'All' | 'Pharmacy' | 'Clinic' | 'Dispenser';
type ViewMode = 'list' | 'map';

export const ShopScreen: React.FC<ShopScreenProps> = ({ 
  isDarkMode, 
  cyclePhase,
  wishlist = [],
  onToggleWishlist,
  recentSearches = [],
  onAddRecentSearch,
  onClearRecentSearch
}) => {
  const navigate = useNavigate();
  // State
  const [selectedCategory, setSelectedCategory] = useState<ProductType>('Contraceptive');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [debouncedSearch, setDebouncedSearch] = useState('');
  
  const [sortBy, setSortBy] = useState<SortOption>('Distance');
  const [filterType, setFilterType] = useState<FilterType>('All');
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [activePhaseFilter, setActivePhaseFilter] = useState<CyclePhase | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Map Preview State
  const [previewMerchant, setPreviewMerchant] = useState<Merchant | null>(null);

  // Pull to Refresh State
  const [pullStartY, setPullStartY] = useState(0);
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  // Simulate loading on mount
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1200);
    return () => clearTimeout(timer);
  }, []);

  // Debounce Search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchQuery);
      if (searchQuery && onAddRecentSearch) {
        onAddRecentSearch(searchQuery);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [searchQuery, onAddRecentSearch]);

  // Pull to Refresh Handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (window.scrollY === 0) {
      setPullStartY(e.touches[0].clientY);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (pullStartY > 0 && window.scrollY === 0) {
      const currentY = e.touches[0].clientY;
      const diff = currentY - pullStartY;
      if (diff > 0) {
        setPullDistance(diff * 0.4); // Resistance
      }
    }
  };

  const handleTouchEnd = () => {
    if (pullDistance > 60) {
      setIsRefreshing(true);
      // Simulate refresh
      setTimeout(() => {
        setIsRefreshing(false);
        setPullDistance(0);
        // Here you would reload data
      }, 1500);
    } else {
      setPullDistance(0);
    }
    setPullStartY(0);
  };

  // Filter Logic for Products
  const filteredProducts = PRODUCTS_DATA.filter(p => {
    const matchesCategory = p.type === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(debouncedSearch.toLowerCase());
    
    // Cycle Phase Filter Logic
    if (activePhaseFilter) {
       let relevantTags: string[] = [];
       if (activePhaseFilter === CyclePhase.MENSTRUAL) relevantTags = ['menstrual', 'flow', 'pain'];
       if (activePhaseFilter === CyclePhase.OVULATION) relevantTags = ['ovulation', 'protection', 'emergency'];
       if (activePhaseFilter === CyclePhase.FOLLICULAR) relevantTags = ['daily', 'fertility'];
       if (activePhaseFilter === CyclePhase.LUTEAL) relevantTags = ['care', 'pms', 'pain'];
       
       const hasTag = p.tags?.some(t => relevantTags.includes(t));
       if (!hasTag) return false;
    }

    return matchesCategory && matchesSearch;
  });

  // Sorting Logic for Products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'Price') {
      return a.price - b.price;
    }
    return 0; // Default to existing order
  });

  // Filter Logic for Facilities (Detail View)
  const filteredFacilities = MOCK_MERCHANTS.filter(m => 
    (filterType === 'All' || m.type === filterType) &&
    selectedProduct && (m.stock[selectedProduct.id] !== undefined) // Only show if they carry the item logic (simplified)
  );

  // Sorting Logic for Facilities
  const sortedFacilities = [...filteredFacilities].sort((a, b) => {
    if (sortBy === 'Distance') {
      return parseFloat(a.distance) - parseFloat(b.distance);
    }
    return parseFloat(a.distance) - parseFloat(b.distance);
  });

  // Styles
  const textMain = isDarkMode ? 'text-white' : 'text-gray-800';
  const textSub = isDarkMode ? 'text-gray-400' : 'text-gray-500';
  const glassHeader = isDarkMode ? 'bg-lavender-950/95 border-white/5' : 'bg-white/95 border-gray-100';
  const searchBg = isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-50 border-gray-200 text-gray-800';
  
  // Theme Color Logic
  const isPink = selectedCategory === 'Contraceptive';
  const activeThemeText = isPink ? 'text-pink-600' : 'text-emerald-600';
  const hoverThemeText = isPink ? 'group-hover:text-pink-600' : 'group-hover:text-emerald-600';
  const activeChipBg = isDarkMode ? 'bg-white text-black' : 'bg-gray-800 text-white';
  const inactiveChip = isDarkMode ? 'bg-white/5 text-gray-400 border-transparent' : 'bg-white text-gray-600 border-gray-200';

  // Helper for Phase Filter Colors
  const getPhaseStyles = (phase: CyclePhase) => {
    const isActive = activePhaseFilter === phase;
    switch (phase) {
      case CyclePhase.MENSTRUAL:
        return isActive 
          ? 'bg-pink-500 text-white border-pink-500' 
          : (isDarkMode ? 'bg-pink-900/10 text-pink-300 border-pink-500/20' : 'bg-pink-50 text-pink-600 border-pink-100');
      case CyclePhase.FOLLICULAR:
        return isActive 
          ? 'bg-teal-500 text-white border-teal-500' 
          : (isDarkMode ? 'bg-teal-900/10 text-teal-300 border-teal-500/20' : 'bg-teal-50 text-teal-600 border-teal-100');
      case CyclePhase.OVULATION:
        return isActive 
          ? 'bg-purple-600 text-white border-purple-600' 
          : (isDarkMode ? 'bg-purple-900/10 text-purple-300 border-purple-500/20' : 'bg-purple-50 text-purple-600 border-purple-100');
      case CyclePhase.LUTEAL:
        return isActive 
          ? 'bg-indigo-500 text-white border-indigo-500' 
          : (isDarkMode ? 'bg-indigo-900/10 text-indigo-300 border-indigo-500/20' : 'bg-indigo-50 text-indigo-600 border-indigo-100');
      default: return '';
    }
  };

  const handleRecentSearchClick = (term: string) => {
    setSearchQuery(term);
    setIsSearchFocused(false);
  };

  return (
    <div 
      ref={contentRef}
      className="pb-24 animate-fade-in relative min-h-screen"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Pull to Refresh Indicator */}
      <div 
        className="fixed top-20 left-0 right-0 z-40 flex justify-center pointer-events-none transition-transform duration-200"
        style={{ transform: `translateY(${pullDistance > 0 ? pullDistance - 40 : -100}px)` }}
      >
        <div className={`w-10 h-10 rounded-full flex items-center justify-center shadow-md ${isDarkMode ? 'bg-lavender-900 text-purple-400' : 'bg-white text-purple-600'}`}>
           <RefreshCw size={20} className={isRefreshing ? 'animate-spin' : ''} style={{ transform: `rotate(${pullDistance * 2}deg)` }} />
        </div>
      </div>

      {/* 1. The Sticky Control Header */}
      <div className={`sticky top-0 z-30 backdrop-blur-md border-b -mx-6 px-6 py-3 shadow-sm transition-colors duration-500 ${glassHeader}`}>
        
        {/* Row 1: Title & Sort/Back */}
        <div className="flex justify-between items-center mb-3">
          {selectedProduct ? (
            <button 
              onClick={() => setSelectedProduct(null)}
              className={`flex items-center gap-1 text-sm font-semibold ${textMain} hover:opacity-80`}
            >
              <ArrowLeft size={18} /> Back
            </button>
          ) : (
             <h2 className={`text-xl font-bold ${textMain}`}>Shop</h2>
          )}
         
          <div className="flex items-center gap-2">
            {/* View Mode Toggle (Map vs List) */}
            {selectedProduct && (
              <div className={`p-1 rounded-lg flex ${isDarkMode ? 'bg-white/10' : 'bg-gray-100'}`}>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-1.5 rounded-md transition-all ${viewMode === 'list' ? 'bg-white shadow-sm' : ''} ${isDarkMode && viewMode === 'list' ? 'text-black' : ''}`}
                >
                  <List size={14} />
                </button>
                <button
                  onClick={() => setViewMode('map')}
                  className={`p-1.5 rounded-md transition-all ${viewMode === 'map' ? 'bg-white shadow-sm' : ''} ${isDarkMode && viewMode === 'map' ? 'text-black' : ''}`}
                >
                  <MapIcon size={14} />
                </button>
              </div>
            )}

            {/* Sort Control */}
            <div className={`p-1 rounded-lg flex ${isDarkMode ? 'bg-white/10' : 'bg-gray-100'}`}>
              {['Distance', 'Price'].map((opt) => (
                <button
                  key={opt}
                  onClick={() => setSortBy(opt as SortOption)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                    sortBy === opt 
                      ? `bg-white shadow-sm ${isDarkMode ? 'bg-lavender-800 text-white' : activeThemeText}`
                      : `${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Row 2: Search Bar */}
        <div className="relative mb-3 z-50">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search products..."
            className={`w-full py-2 pl-10 pr-4 rounded-xl text-sm outline-none focus:ring-1 focus:ring-pink-300 transition-all ${searchBg} ${isSearchFocused ? 'ring-2 ring-pink-300' : ''}`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
          />
          
          {/* Recent Searches Dropdown */}
          {isSearchFocused && recentSearches.length > 0 && (
            <div className={`absolute top-full left-0 right-0 mt-2 p-2 rounded-xl border shadow-xl backdrop-blur-xl animate-fade-in ${isDarkMode ? 'bg-night-surface/95 border-white/10' : 'bg-white/95 border-gray-100'}`}>
               <div className="flex justify-between items-center px-2 py-1 mb-1">
                 <span className={`text-[10px] font-bold uppercase tracking-wider ${textSub}`}>Recent</span>
                 <button onClick={onClearRecentSearch} className={`text-[10px] hover:text-red-500 ${textSub}`}>Clear</button>
               </div>
               {recentSearches.map((term, i) => (
                 <button
                   key={i}
                   onClick={() => handleRecentSearchClick(term)}
                   className={`w-full text-left px-3 py-2 rounded-lg flex items-center gap-3 text-sm transition-colors ${isDarkMode ? 'hover:bg-white/10 text-gray-300' : 'hover:bg-gray-50 text-gray-700'}`}
                 >
                   <Clock size={14} className="text-gray-400" />
                   {term}
                 </button>
               ))}
            </div>
          )}
        </div>

        {/* Row 3: Filter Chips */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar mb-3">
          {/* Quick Action: Sync to My Cycle */}
          {!selectedProduct && cyclePhase && (
            <button
              onClick={() => setActivePhaseFilter(activePhaseFilter === cyclePhase ? null : cyclePhase)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border whitespace-nowrap transition-colors ${
                activePhaseFilter === cyclePhase
                  ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white border-transparent' 
                  : (isDarkMode ? 'bg-white/5 text-purple-300 border-purple-500/30' : 'bg-purple-50 text-purple-600 border-purple-100')
              }`}
            >
              <Sprout size={12} />
              Sync to My Cycle
            </button>
          )}

          {['All', 'Pharmacy', 'Clinic', 'Dispenser'].map((f) => (
            <button
              key={f}
              onClick={() => setFilterType(f as FilterType)}
              className={`px-3 py-1 rounded-full text-xs font-medium border whitespace-nowrap transition-colors ${
                filterType === f ? activeChipBg : inactiveChip
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Row 4: Category Toggles (Bottom Lip) */}
        {!selectedProduct && (
          <div className={`pt-2 border-t flex gap-2 ${isDarkMode ? 'border-white/5' : 'border-gray-50'}`}>
            <button
              onClick={() => setSelectedCategory('Contraceptive')}
              className={`flex-1 py-1.5 text-xs font-bold uppercase tracking-wide rounded-lg transition-colors ${
                selectedCategory === 'Contraceptive'
                  ? 'bg-pink-500 text-white'
                  : (isDarkMode ? 'bg-pink-900/20 text-pink-300' : 'bg-pink-50 text-pink-700')
              }`}
            >
              Contraceptives
            </button>
            <button
              onClick={() => setSelectedCategory('Hygiene')}
              className={`flex-1 py-1.5 text-xs font-bold uppercase tracking-wide rounded-lg transition-colors ${
                selectedCategory === 'Hygiene'
                  ? 'bg-emerald-600 text-white' 
                  : (isDarkMode ? 'bg-emerald-900/20 text-emerald-300' : 'bg-emerald-50 text-emerald-700')
              }`}
            >
              Hygiene
            </button>
          </div>
        )}
      </div>

      {/* 2. Main View vs Detail View */}
      <div className="mt-4">
        {selectedProduct ? (
          // --- DETAIL VIEW (Facilities List OR Map) ---
          <div className="space-y-4 animate-slide-up">
            <div className={`p-4 rounded-xl mb-4 flex justify-between items-start ${isDarkMode ? 'bg-white/5' : 'bg-gray-50'}`}>
               <div>
                 <h3 className={`font-bold ${textMain}`}>{selectedProduct.name}</h3>
                 <p className={`text-xs ${textSub}`}>{selectedProduct.description}</p>
               </div>
               <div className={`text-sm font-bold ${textMain}`}>
                 {selectedProduct.price.toLocaleString()} RWF
               </div>
            </div>
            
            <h4 className={`text-xs font-bold uppercase tracking-wider mb-2 ${textSub}`}>Available At</h4>
            
            {viewMode === 'map' ? (
              // --- GENTLE MAP VIEW (Google Maps Integration) ---
              <div className="relative w-full aspect-square rounded-2xl overflow-hidden shadow-inner border border-white/10">
                <GentleMap 
                  merchants={sortedFacilities} 
                  isDarkMode={isDarkMode} 
                  onMarkerClick={(m) => setPreviewMerchant(m)}
                  className="w-full h-full"
                />
                
                {/* Merchant Summary Slide-up Card */}
                {previewMerchant && (
                  <div className="absolute bottom-4 left-4 right-4 z-10 animate-slide-up">
                    <div className={`p-4 rounded-2xl shadow-xl backdrop-blur-xl border ${isDarkMode ? 'bg-lavender-950/90 border-white/10 text-white' : 'bg-white/95 border-white/50 text-gray-800'}`}>
                        <div className="flex justify-between items-start mb-2">
                            <div>
                                <h3 className="font-bold text-sm">{previewMerchant.name}</h3>
                                <p className="text-xs opacity-70 mt-0.5">{previewMerchant.type} • {previewMerchant.distance} away</p>
                            </div>
                            <button onClick={() => setPreviewMerchant(null)} className="p-1 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"><X size={16}/></button>
                        </div>
                        <div className="flex gap-2 mt-3">
                            <button onClick={() => navigate(`/merchant/${previewMerchant.id}`)} className="flex-1 py-2.5 bg-pink-500 hover:bg-pink-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-pink-500/30 transition-all">
                              View Shop
                            </button>
                            <button className={`flex-1 py-2.5 border rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${isDarkMode ? 'border-white/20 hover:bg-white/5' : 'border-gray-200 hover:bg-gray-50'}`}>
                              <Navigation size={12} /> Directions
                            </button>
                        </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              // --- LIST VIEW ---
              isLoading ? (
                <div className="space-y-3">
                  <FacilitySkeleton isDarkMode={isDarkMode} />
                  <FacilitySkeleton isDarkMode={isDarkMode} />
                  <FacilitySkeleton isDarkMode={isDarkMode} />
                </div>
              ) : sortedFacilities.length > 0 ? (
                sortedFacilities.map((merchant, index) => (
                  <div 
                    key={merchant.id} 
                    className="animate-fade-in" 
                    style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'both' }}
                  >
                    <FacilityCard 
                      merchant={merchant} 
                      productId={selectedProduct.id} 
                      isDarkMode={isDarkMode}
                      onClick={() => navigate(`/merchant/${merchant.id}`)}
                      isWishlisted={wishlist.includes(merchant.id)}
                      onToggleWishlist={onToggleWishlist}
                    />
                  </div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center animate-fade-in">
                  <div className={`w-28 h-28 rounded-full flex items-center justify-center mb-5 ${isDarkMode ? 'bg-white/5' : 'bg-gradient-to-tr from-pink-50 to-teal-50'}`}>
                     <Sprout size={48} className={isDarkMode ? 'text-teal-400' : 'text-teal-600'} strokeWidth={1} />
                  </div>
                  <h3 className={`font-bold text-lg mb-2 ${textMain}`}>Growing Together</h3>
                  <p className={`text-sm max-w-[220px] leading-relaxed ${textSub}`}>
                    No merchants found nearby with this item. We're adding new partners every week.
                  </p>
                </div>
              )
            )}
          </div>
        ) : (
          // --- MAIN VIEW (Product Category List) ---
          <div key={selectedCategory} className="animate-fade-in">
             
             {/* Cycle-Synced Shopping Filters */}
             <div className="mb-4 overflow-x-auto no-scrollbar pb-2 -mx-6 px-6">
                <div className="flex gap-2">
                  <div className="flex items-center gap-1.5 px-1">
                    <Filter size={14} className={textSub} />
                    <span className={`text-[10px] uppercase font-bold tracking-wider ${textSub}`}>Phase</span>
                  </div>
                  {[CyclePhase.MENSTRUAL, CyclePhase.FOLLICULAR, CyclePhase.OVULATION, CyclePhase.LUTEAL].map(phase => (
                    <button
                      key={phase}
                      onClick={() => setActivePhaseFilter(activePhaseFilter === phase ? null : phase)}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold border transition-all whitespace-nowrap shadow-sm active:scale-95 ${getPhaseStyles(phase)}`}
                    >
                      {phase === CyclePhase.FOLLICULAR ? 'Fertile' : phase}
                    </button>
                  ))}
                </div>
             </div>

             <div className={`px-1 mb-2 text-xs font-bold uppercase tracking-wider ${textSub}`}>
               {selectedCategory}
             </div>
             
             <div className={`rounded-xl border overflow-hidden ${isDarkMode ? 'bg-lavender-900/40 border-white/10' : 'bg-white/60 border-gray-100'}`}>
               <ul className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-gray-50'}`}>
                 {isLoading ? (
                    <>
                      <ProductSkeleton isDarkMode={isDarkMode} />
                      <ProductSkeleton isDarkMode={isDarkMode} />
                      <ProductSkeleton isDarkMode={isDarkMode} />
                      <ProductSkeleton isDarkMode={isDarkMode} />
                    </>
                 ) : sortedProducts.map((product, index) => (
                   <li 
                    key={product.id}
                    onClick={() => setSelectedProduct(product)}
                    className={`p-4 flex items-center justify-between cursor-pointer group transition-all duration-200 ease-out animate-fade-in relative ${
                      isDarkMode 
                        ? 'hover:bg-white/5 hover:shadow-md active:scale-[0.99] hover:-translate-y-0.5' 
                        : 'hover:bg-white hover:shadow-md active:scale-[0.99] hover:-translate-y-0.5'
                    }`}
                    style={{ animationDelay: `${index * 75}ms`, animationFillMode: 'both' }}
                   >
                     <div>
                       <h4 className={`text-sm font-medium transition-colors ${textMain} ${hoverThemeText}`}>
                         {product.name}
                       </h4>
                       <p className={`text-[10px] mt-0.5 ${textSub}`}>
                         {product.description}
                       </p>
                       {/* Cycle Sync Tag */}
                       {product.tags && (
                         <div className="mt-1 flex gap-1">
                            {product.tags.slice(0, 2).map(t => (
                              <span key={t} className={`text-[9px] px-1.5 py-0.5 rounded-full uppercase tracking-wider font-bold ${
                                activePhaseFilter 
                                  ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white shadow-sm' 
                                  : 'bg-gray-100 text-gray-500 dark:bg-white/10 dark:text-gray-400'
                              }`}>
                                {t}
                              </span>
                            ))}
                         </div>
                       )}
                     </div>
                     <div className="flex items-center gap-3">
                       <span className={`text-xs font-semibold ${textSub}`}>
                         {product.price.toLocaleString()} RWF
                       </span>
                       <ChevronRight size={16} className={isDarkMode ? 'text-gray-600' : 'text-gray-300'} />
                     </div>
                   </li>
                 ))}
               </ul>
               {!isLoading && sortedProducts.length === 0 && (
                 <div className="flex flex-col items-center justify-center py-12 text-center animate-fade-in">
                    <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${isDarkMode ? 'bg-white/5' : 'bg-gray-50'}`}>
                      <Sprout size={32} className={`opacity-50 ${isDarkMode ? 'text-teal-400' : 'text-teal-600'}`} />
                    </div>
                    <p className={`text-sm ${textSub}`}>No products found for this phase.</p>
                 </div>
               )}
             </div>
          </div>
        )}
      </div>
    </div>
  );
};
