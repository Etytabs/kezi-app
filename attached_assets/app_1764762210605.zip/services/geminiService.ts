
import { GoogleGenAI, Type } from "@google/genai";
import { InspirationContent, CyclePhase, JournalEntry } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const fetchDailyInspiration = async (phase: CyclePhase): Promise<InspirationContent> => {
  try {
    const prompt = `Generate a short, comforting, and empowering daily health insight or inspirational quote for a woman in the ${phase} phase of her menstrual cycle. Keep it under 40 words. Focus on wellness, reproductive rights, or self-care.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "A short 2-3 word title" },
            body: { type: Type.STRING, description: "The insight text" },
            source: { type: Type.STRING, description: "Optional source or 'Jasmin Team'" }
          },
          required: ["title", "body"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    const parsed = JSON.parse(text);
    // Add missing id property required by InspirationContent
    return { ...parsed, id: `gemini-${Date.now()}` } as InspirationContent;

  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback content if API fails or key is missing
    return {
      id: 'fallback',
      title: "Daily Wisdom",
      body: "Listen to your body today. Rest is a form of productivity.",
      source: "Jasmin Offline"
    };
  }
};

export const generateJournalSummary = async (entries: JournalEntry[]): Promise<string> => {
  if (entries.length === 0) return "Start journaling to see insights here.";

  try {
    // Take the last 5 entries to avoid token limits and keep it relevant
    const recentEntries = entries.slice(0, 5).map(e => `Date: ${e.date}, Content: ${e.content}`).join('\n');
    
    const prompt = `
      Analyze these recent journal entries from a cycle tracking app. 
      Provide a brief, supportive summary (max 3 sentences) identifying recurring themes in mood or physical symptoms.
      Address the user directly as "you".
      
      Entries:
      ${recentEntries}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Unable to generate summary.";
  } catch (error) {
    console.error("Gemini Summary Error:", error);
    return "Unable to analyze journal entries right now. Please try again later.";
  }
};
