const express = require('express');
const cors = require('cors');
const path = require('path');
const { PrismaClient } = require('@prisma/client');

const app = express();
const prisma = new PrismaClient();

app.use(cors());
app.use(express.json());

// Serve Static Files (Production Build)
app.use(express.static(path.join(__dirname, 'dist')));

// --- Auth Routes ---
app.post('/api/auth/login', async (req, res) => {
  const { email } = req.body;
  try {
    let user = await prisma.user.findUnique({ 
        where: { email },
        include: { profiles: true, cycleConfig: true }
    });
    
    if (!user) {
      const role = email === 'admin@jasmin.app' ? 'admin' : 'user';
      user = await prisma.user.create({
        data: {
          name: email.split('@')[0],
          email,
          role,
          activeProfileId: 'main',
          wishlist: '[]',
          recentSearches: '[]'
        },
        include: { profiles: true, cycleConfig: true }
      });
    }

    // Parse JSON fields
    user.wishlist = JSON.parse(user.wishlist || '[]');
    user.recentSearches = JSON.parse(user.recentSearches || '[]');
    
    // Mock JWT
    const token = `mock_jwt_${user.id}`;
    res.json({ user, token });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Login failed" });
  }
});

// --- User & Admin Routes ---
app.get('/api/users', async (req, res) => {
  try {
    const users = await prisma.user.findMany({ include: { profiles: true } });
    res.json(users);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch users" });
  }
});

app.put('/api/users/:id', async (req, res) => {
  const { id } = req.params;
  const data = req.body;
  try {
    const user = await prisma.user.update({
      where: { id },
      data: {
        name: data.name,
        role: data.role,
        avatar: data.avatar,
        wishlist: JSON.stringify(data.wishlist),
        recentSearches: JSON.stringify(data.recentSearches),
        activeProfileId: data.activeProfileId
      },
      include: { profiles: true }
    });
    
    // Parse JSON back for response
    user.wishlist = JSON.parse(user.wishlist || '[]');
    user.recentSearches = JSON.parse(user.recentSearches || '[]');
    
    res.json(user);
  } catch (e) {
    res.status(500).json({ error: "Update failed" });
  }
});

app.post('/api/users/:id/profiles', async (req, res) => {
  const { id } = req.params;
  try {
    await prisma.dependentProfile.create({
      data: {
        ...req.body,
        userId: id
      }
    });
    const user = await prisma.user.findUnique({ where: { id }, include: { profiles: true } });
    res.json(user);
  } catch (e) {
    res.status(500).json({ error: "Profile creation failed" });
  }
});

// --- Cycle Routes ---
app.get('/api/cycle', async (req, res) => {
  // In real app, get userId from auth middleware
  // For demo, find first user or specific
  const config = await prisma.cycleConfig.findFirst();
  if (config) {
    res.json(config);
  } else {
    // Default
    res.json({ lastPeriodDate: '2025-11-01', cycleLength: 28 });
  }
});

app.post('/api/cycle', async (req, res) => {
  const { lastPeriodDate, cycleLength } = req.body;
  // Upsert for demo user (assuming single user context for simplicity without auth middleware)
  // Logic would ideally use req.user.id
  const user = await prisma.user.findFirst();
  if (user) {
    const config = await prisma.cycleConfig.upsert({
        where: { userId: user.id },
        update: { lastPeriodDate, cycleLength },
        create: { userId: user.id, lastPeriodDate, cycleLength }
    });
    res.json(config);
  } else {
    res.status(401).json({ error: "No user" });
  }
});

app.get('/api/journal', async (req, res) => {
  const entries = await prisma.journalEntry.findMany({ orderBy: { date: 'desc' } });
  const parsed = entries.map(e => ({ ...e, tags: JSON.parse(e.tags || '[]') }));
  res.json(parsed);
});

app.post('/api/journal', async (req, res) => {
  const user = await prisma.user.findFirst();
  if (!user) return res.status(401).json({error: "No user"});
  
  const entry = await prisma.journalEntry.create({
    data: {
      date: req.body.date,
      content: req.body.content,
      tags: JSON.stringify(req.body.tags || []),
      userId: user.id
    }
  });
  res.json({ ...entry, tags: JSON.parse(entry.tags) });
});

// --- Marketplace Routes ---
app.get('/api/merchants', async (req, res) => {
  const merchants = await prisma.merchant.findMany({ include: { stock: true } });
  const formatted = merchants.map(m => ({
    ...m,
    stock: m.stock.reduce((acc, item) => ({ ...acc, [item.productId]: item.count }), {})
  }));
  res.json(formatted);
});

app.post('/api/merchants/:id/reserve', async (req, res) => {
  const { productId, quantity } = req.body;
  const { id } = req.params;

  try {
    const stock = await prisma.stock.findUnique({
        where: { merchantId_productId: { merchantId: id, productId } }
    });

    if (stock && stock.count >= quantity) {
        await prisma.stock.update({
            where: { id: stock.id },
            data: { count: stock.count - quantity }
        });
        res.json({ success: true });
    } else {
        res.status(400).json({ success: false, error: "Out of stock" });
    }
  } catch (e) {
    res.status(500).json({ success: false });
  }
});

// SPA Fallback: Serve index.html for any other route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Jasmin Server running on port ${PORT}`);
});