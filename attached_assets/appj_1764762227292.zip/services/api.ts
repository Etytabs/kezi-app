
import { CycleData, Merchant, User, CyclePhase, JournalEntry, DependentProfile, CycleConfig } from "../types";
import { MOCK_CYCLE_DATA, MOCK_MERCHANTS } from "../constants";
import { cycleService } from "./cycleService";

const API_BASE = '/api'; // Proxied to localhost:3000 via Vite

const STORAGE_KEYS = {
  TOKEN: 'jasmin_token',
  USER: 'jasmin_user',
  SYNC_QUEUE: 'jasmin_sync_queue',
  CYCLE_CONFIG: 'jasmin_cycle_config'
};

interface SyncAction {
  type: 'JOURNAL_ADD' | 'USER_UPDATE' | 'RESERVE_STOCK';
  payload: any;
  timestamp: number;
}

export const api = {
  // --- Sync Strategy ---
  syncData: async () => {
    const queueStr = localStorage.getItem(STORAGE_KEYS.SYNC_QUEUE);
    if (!queueStr) return;

    const queue: SyncAction[] = JSON.parse(queueStr);
    if (queue.length === 0) return;

    console.log(`[Sync] Processing ${queue.length} items...`);

    const remainingQueue: SyncAction[] = [];

    for (const action of queue) {
        try {
            if (action.type === 'JOURNAL_ADD') {
                await fetch(`${API_BASE}/journal`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(action.payload)
                });
            }
            // Add other handlers here
        } catch (e) {
            console.error("Sync failed for item", action);
            remainingQueue.push(action);
        }
    }

    if (remainingQueue.length > 0) {
        localStorage.setItem(STORAGE_KEYS.SYNC_QUEUE, JSON.stringify(remainingQueue));
    } else {
        localStorage.removeItem(STORAGE_KEYS.SYNC_QUEUE);
    }
  },

  // --- Auth & User ---
  getCurrentUser: async (): Promise<User | null> => {
    const token = localStorage.getItem(STORAGE_KEYS.TOKEN);
    const userStr = localStorage.getItem(STORAGE_KEYS.USER);
    if (token && userStr) {
        return JSON.parse(userStr);
    }
    return null;
  },

  login: async (email: string): Promise<User> => {
    try {
        const res = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });
        
        if (!res.ok) throw new Error("Login failed");
        
        const data = await res.json();
        localStorage.setItem(STORAGE_KEYS.TOKEN, data.token);
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(data.user));
        return data.user;
    } catch (e) {
        console.error("API Login failed, falling back to mock for demo");
        // Fallback for demo purposes if backend isn't running
        const user: User = { 
            id: 'mock_u1', 
            name: email.split('@')[0], 
            email, 
            role: email.includes('admin') ? 'admin' : 'user',
            profiles: [],
            activeProfileId: 'main'
        };
        localStorage.setItem(STORAGE_KEYS.TOKEN, 'mock_token');
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
        return user;
    }
  },

  logout: async () => {
    localStorage.removeItem(STORAGE_KEYS.TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER);
  },

  getUsers: async (): Promise<User[]> => {
    try {
        const res = await fetch(`${API_BASE}/users`);
        if (res.ok) return await res.json();
    } catch (e) {}
    return [];
  },

  updateUser: async (user: User): Promise<User> => {
    // Optimistic Local Update
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));

    try {
        await fetch(`${API_BASE}/users/${user.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(user)
        });
    } catch (e) {
        console.warn("Offline: User update queued not implemented fully");
    }
    return user;
  },

  addDependentProfile: async (userId: string, profile: Omit<DependentProfile, 'id'>): Promise<User> => {
    const res = await fetch(`${API_BASE}/users/${userId}/profiles`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile)
    });
    const updatedUser = await res.json();
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedUser));
    return updatedUser;
  },

  switchActiveProfile: async (userId: string, profileId: string): Promise<User> => {
    const currentUser = await api.getCurrentUser();
    if (!currentUser) throw new Error("No user");
    
    const updated = { ...currentUser, activeProfileId: profileId };
    return api.updateUser(updated);
  },

  // --- Cycle ---
  getCycleData: async (): Promise<CycleData> => {
    let config: CycleConfig;
    
    try {
        // Try Fetch
        const res = await fetch(`${API_BASE}/cycle`);
        if (res.ok) {
            config = await res.json();
            // Cache config
            localStorage.setItem(STORAGE_KEYS.CYCLE_CONFIG, JSON.stringify(config));
        } else {
            throw new Error("API Error");
        }
    } catch (e) {
        // Fallback to local
        const local = localStorage.getItem(STORAGE_KEYS.CYCLE_CONFIG);
        config = local ? JSON.parse(local) : { lastPeriodDate: '2025-11-01', cycleLength: 28 };
    }

    const start = new Date(config.lastPeriodDate);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    let currentDay = (diffDays % config.cycleLength) + 1;
    if (currentDay === 0) currentDay = 1;

    const phase = cycleService.calculatePhase(currentDay, config.cycleLength);

    return {
        currentDay,
        totalLength: config.cycleLength,
        phase,
        nextPeriodDays: config.cycleLength - currentDay + 1,
        startDate: config.lastPeriodDate
    };
  },

  updateCycleConfig: async (config: CycleConfig): Promise<CycleData> => {
    try {
        await fetch(`${API_BASE}/cycle`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });
    } catch (e) {
        // Offline support could go here
    }
    localStorage.setItem(STORAGE_KEYS.CYCLE_CONFIG, JSON.stringify(config));
    return api.getCycleData();
  },

  // --- Journal ---
  getJournalEntries: async (): Promise<JournalEntry[]> => {
    try {
        const res = await fetch(`${API_BASE}/journal`);
        if (res.ok) return await res.json();
    } catch (e) {}
    return [];
  },

  addJournalEntry: async (entry: Omit<JournalEntry, 'id'>): Promise<JournalEntry> => {
    const tempId = `temp_${Date.now()}`;
    const newEntry = { ...entry, id: tempId, _pending: !navigator.onLine };

    if (!navigator.onLine) {
        const queue = JSON.parse(localStorage.getItem(STORAGE_KEYS.SYNC_QUEUE) || '[]');
        queue.push({ type: 'JOURNAL_ADD', payload: newEntry, timestamp: Date.now() });
        localStorage.setItem(STORAGE_KEYS.SYNC_QUEUE, JSON.stringify(queue));
        return newEntry;
    }

    try {
        const res = await fetch(`${API_BASE}/journal`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(entry)
        });
        return await res.json();
    } catch (e) {
        return newEntry;
    }
  },

  // --- Marketplace ---
  getMerchants: async (): Promise<Merchant[]> => {
    try {
        const res = await fetch(`${API_BASE}/merchants`);
        if (res.ok) return await res.json();
    } catch (e) {
        console.warn("Using mock merchants");
        return MOCK_MERCHANTS;
    }
    return MOCK_MERCHANTS;
  },

  getMerchantsInBounds: async (): Promise<Merchant[]> => {
      // Simplified for now
      return api.getMerchants();
  },

  getStock: async () => ({ status: 'ok' }),

  reserveStock: async (merchantId: string, productId: string, quantity: number): Promise<boolean> => {
    try {
        const res = await fetch(`${API_BASE}/merchants/${merchantId}/reserve`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ productId, quantity })
        });
        return res.ok;
    } catch (e) {
        return false;
    }
  }
};
