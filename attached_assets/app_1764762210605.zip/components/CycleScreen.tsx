
import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Lock, 
  ChevronLeft, 
  ChevronRight, 
  Droplets, 
  Baby, 
  Zap, 
  Moon, 
  X, 
  Save, 
  Smile,
  Frown,
  Activity,
  Shield,
  Sparkles,
  Loader2,
  CloudOff,
  Settings,
  Calendar,
  Info
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { CycleWheel } from './CycleWheel';
import { DailyInspiration } from './DailyInspiration';
import { CycleData, CyclePhase, JournalEntry } from '../types';
import { api } from '../services/api';
import { cycleService } from '../services/cycleService';
import { generateJournalSummary } from '../services/geminiService';

interface CycleScreenProps {
  data: CycleData;
  isDarkMode: boolean;
  discreetMode: boolean;
}

export const CycleScreen: React.FC<CycleScreenProps> = ({ data: initialData, isDarkMode, discreetMode }) => {
  const navigate = useNavigate();
  
  // State
  const [data, setData] = useState<CycleData>(initialData);
  const [selectedDay, setSelectedDay] = useState<number>(initialData.currentDay);
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  
  // Cycle Config State
  const [editStartDate, setEditStartDate] = useState(initialData.startDate || new Date().toISOString().split('T')[0]);
  const [editLength, setEditLength] = useState(initialData.totalLength.toString());

  // Journal State
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>([]);
  const [journalSummary, setJournalSummary] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [showJournalHistory, setShowJournalHistory] = useState(false);

  // Mock Log State
  const [logData, setLogData] = useState<{
    flow: string;
    mood: string[];
    symptoms: string[];
    sex: string;
    note: string; // Journal Note
  }>({
    flow: 'Medium',
    mood: ['Happy'],
    symptoms: ['Cramps'],
    sex: 'Protected',
    note: ''
  });

  useEffect(() => {
    // Refresh data on mount in case it was updated elsewhere
    const refresh = async () => {
      const freshData = await api.getCycleData();
      setData(freshData);
      setSelectedDay(freshData.currentDay);
      setEditStartDate(freshData.startDate || new Date().toISOString().split('T')[0]);
    };
    refresh();
    loadJournal();
  }, []);

  const loadJournal = async () => {
    const entries = await api.getJournalEntries();
    setJournalEntries(entries);
  };

  const handleUpdateConfig = async () => {
    const newData = await api.updateCycleConfig({
      lastPeriodDate: editStartDate,
      cycleLength: parseInt(editLength) || 28
    });
    setData(newData);
    setSelectedDay(newData.currentDay);
    setIsConfigModalOpen(false);
  };

  const handleGenerateSummary = async () => {
    setIsSummarizing(true);
    const summary = await generateJournalSummary(journalEntries);
    setJournalSummary(summary);
    setIsSummarizing(false);
  };

  const handleSaveLog = async () => {
    if (logData.note.trim()) {
      await api.addJournalEntry({
        date: new Date().toISOString().split('T')[0], 
        content: logData.note,
        tags: [...logData.mood, ...logData.symptoms]
      });
      await loadJournal();
    }
    setLogData(prev => ({...prev, note: ''}));
    setIsLogModalOpen(false);
  };

  const textMain = isDarkMode ? 'text-white' : 'text-gray-800';
  const textSub = isDarkMode ? 'text-gray-400' : 'text-gray-500';
  
  const getInsightStyle = () => {
    switch (data.phase) {
      case CyclePhase.MENSTRUAL: return 'bg-gradient-to-r from-pink-500 to-rose-500';
      case CyclePhase.FOLLICULAR: return 'bg-gradient-to-r from-teal-400 to-emerald-500';
      case CyclePhase.OVULATION: return 'bg-gradient-to-r from-purple-500 to-indigo-500';
      default: return 'bg-gradient-to-r from-slate-400 to-slate-600';
    }
  };

  const getPhaseIcon = () => {
    switch (data.phase) {
      case CyclePhase.MENSTRUAL: return <Droplets size={18} className="text-white" />;
      case CyclePhase.FOLLICULAR: return <Baby size={18} className="text-white" />;
      case CyclePhase.OVULATION: return <Zap size={18} className="text-white" />;
      default: return <Moon size={18} className="text-white" />;
    }
  };

  const getInsightText = () => {
    switch (data.phase) {
      case CyclePhase.MENSTRUAL: return "Hydration is key today. Gentle stretching can help alleviate cramps.";
      case CyclePhase.FOLLICULAR: return "Energy levels are rising. Great time for complex tasks and workouts.";
      case CyclePhase.OVULATION: return "Peak fertility. You might feel more social and energetic today.";
      default: return "Progesterone is rising. Prioritize sleep and comforting foods.";
    }
  };

  const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  const currentMonthDays = Array.from({ length: 30 }, (_, i) => i + 1);
  const startOffset = 2;

  const getPhaseStyles = (status: 'period' | 'fertile' | 'ovulation' | 'none') => {
    const base = "absolute inset-1.5 rounded-full opacity-50";
    switch (status) {
      case 'period': return `${base} ${isDarkMode ? 'bg-pink-600' : 'bg-pink-300'}`;
      case 'fertile': return `${base} ${isDarkMode ? 'bg-teal-700' : 'bg-teal-200'}`;
      case 'ovulation': return `${base} ${isDarkMode ? 'bg-purple-500' : 'bg-purple-400'} ring-1 ring-white`;
      default: return null;
    }
  };

  const handleQuickAdd = (type: 'flow' | 'symptom' | 'mood', value: string) => {
    setLogData(prev => {
      const newState = { ...prev };
      if (type === 'flow') {
        newState.flow = value;
      } else if (type === 'symptom') {
        if (!newState.symptoms.includes(value)) newState.symptoms = [...newState.symptoms, value];
      } else if (type === 'mood') {
        if (!newState.mood.includes(value)) newState.mood = [...newState.mood, value];
      }
      return newState;
    });
    setIsLogModalOpen(true);
  };

  const selectedDayStatus = cycleService.getDayStatus(selectedDay, data.totalLength);

  return (
    <div className="pb-24 animate-fade-in font-sans">
      {/* 2. Header Bar */}
      <div className="flex justify-between items-center mb-4 px-1">
        <button 
          onClick={() => navigate(-1)}
          className={`flex items-center gap-1 text-sm font-medium transition-opacity hover:opacity-70 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}
        >
          <ArrowLeft size={18} />
          Back
        </button>
        <div className="flex gap-2">
            <button 
                onClick={() => setIsConfigModalOpen(true)}
                className={`p-1.5 rounded-full ${isDarkMode ? 'bg-white/10 hover:bg-white/20' : 'bg-gray-100 hover:bg-gray-200'}`}
            >
                <Settings size={14} className={textSub} />
            </button>
            <div className={`flex items-center gap-1 px-2 py-1 rounded-full ${isDarkMode ? 'bg-white/10' : 'bg-gray-100'}`}>
            <Lock size={10} className={isDarkMode ? 'text-gray-400' : 'text-gray-500'} />
            <span className={`text-[10px] font-bold uppercase tracking-wider ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Private
            </span>
            </div>
        </div>
      </div>

      {/* 3. Cycle Wheel (Hero) */}
      <div className="flex flex-col items-center justify-center mb-6">
        <CycleWheel data={data} darkMode={isDarkMode} blur={discreetMode} size={180} />
      </div>

      {/* 4. Daily Insight Card */}
      <div className={`w-full p-4 rounded-2xl shadow-lg mb-6 transition-all duration-500 ${getInsightStyle()} ${discreetMode ? 'blur-sm opacity-50' : ''}`}>
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-full bg-white/20 backdrop-blur-sm">
            {getPhaseIcon()}
          </div>
          <div>
            <h3 className="text-sm font-bold text-white/90 mb-1">Daily Insight</h3>
            <p className="text-xs font-medium text-white/80 leading-relaxed">
              {getInsightText()}
            </p>
          </div>
        </div>
      </div>

      {/* 5. Daily Inspiration Carousel */}
      <DailyInspiration isDarkMode={isDarkMode} />

      {/* 6. Calendar Widget (Advanced Grid) */}
      <div className={`mt-6 rounded-3xl p-4 border backdrop-blur-md ${isDarkMode ? 'bg-lavender-900/60 border-white/5' : 'bg-white border-gray-100'}`}>
        <div className="flex items-center justify-between mb-4">
          <button className={`p-1 rounded-full hover:bg-gray-100/10 ${textSub}`}><ChevronLeft size={20} /></button>
          <span className={`text-lg font-bold ${textMain}`}>Current Cycle</span>
          <button className={`p-1 rounded-full hover:bg-gray-100/10 ${textSub}`}><ChevronRight size={20} /></button>
        </div>

        <div className="grid grid-cols-7 gap-y-2 place-items-center">
          {days.map(d => (
            <span key={d} className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">{d}</span>
          ))}
          {Array.from({ length: startOffset }).map((_, i) => <div key={`e-${i}`} />)}
          
          {currentMonthDays.map(day => {
            const isToday = day === data.currentDay;
            const isSelected = day === selectedDay;
            // Use Service for Status
            const status = cycleService.getDayStatus(day, data.totalLength);
            const phaseClass = getPhaseStyles(status);
            
            // Mock Data Dot Logic: For demo, show log dot on today
            const hasLog = day === data.currentDay;
            
            // Hover Tooltip Text
            let tooltipText = "";
            if (status === 'period') tooltipText = "Menstrual Phase";
            else if (status === 'fertile') tooltipText = "Fertile Window";
            else if (status === 'ovulation') tooltipText = "Ovulation Day";

            return (
              <button
                key={day}
                onClick={() => setSelectedDay(day)}
                title={tooltipText}
                className={`
                  relative h-10 w-10 rounded-full flex flex-col items-center justify-center text-xs transition-all duration-200 z-0
                  ${isSelected 
                    ? (isDarkMode ? 'bg-white text-black scale-110 shadow-lg z-10' : 'bg-gray-800 text-white scale-110 shadow-lg z-10') 
                    : (isToday 
                        ? (isDarkMode ? 'text-pink-300 font-bold ring-1 ring-pink-700' : 'text-pink-600 font-bold ring-1 ring-pink-300')
                        : (isDarkMode ? 'text-gray-300 hover:bg-white/10' : 'text-gray-700 hover:bg-gray-50')
                      )
                  }
                `}
              >
                <span className="z-10">{day}</span>
                {!isSelected && phaseClass && <div className={phaseClass} />}
                {hasLog && (
                  <div className={`absolute bottom-1 w-1 h-1 rounded-full z-20 ${isSelected ? 'bg-pink-500' : (isDarkMode ? 'bg-gray-400' : 'bg-gray-500')}`} />
                )}
              </button>
            );
          })}
        </div>
      </div>
      
      {/* Dynamic Interaction Tip based on Selection */}
      {selectedDayStatus !== 'none' && (
        <div className={`mt-4 mx-1 p-4 rounded-2xl flex items-start gap-3 animate-fade-in ${
          selectedDayStatus === 'period' ? (isDarkMode ? 'bg-pink-900/20 text-pink-200' : 'bg-pink-50 text-pink-800') :
          selectedDayStatus === 'fertile' ? (isDarkMode ? 'bg-teal-900/20 text-teal-200' : 'bg-teal-50 text-teal-800') :
          (isDarkMode ? 'bg-purple-900/20 text-purple-200' : 'bg-purple-50 text-purple-800')
        }`}>
          <div className={`p-2 rounded-full mt-0.5 ${isDarkMode ? 'bg-white/10' : 'bg-white/60'}`}>
            {selectedDayStatus === 'period' && <Droplets size={16} />}
            {selectedDayStatus === 'fertile' && <Baby size={16} />}
            {selectedDayStatus === 'ovulation' && <Zap size={16} />}
          </div>
          <div>
             <h4 className="text-xs font-bold uppercase tracking-wider mb-1">
               {selectedDayStatus === 'period' && 'Menstrual Phase'}
               {selectedDayStatus === 'fertile' && 'Fertile Window'}
               {selectedDayStatus === 'ovulation' && 'Ovulation Day'}
             </h4>
             <p className="text-xs leading-relaxed opacity-90">
               {selectedDayStatus === 'period' && 'It is normal to feel lower energy. Focus on hydration and gentle movement.'}
               {selectedDayStatus === 'fertile' && 'High probability of conception. Use protection if not planning pregnancy.'}
               {selectedDayStatus === 'ovulation' && 'Peak fertility. You may experience a slight rise in body temperature.'}
             </p>
          </div>
        </div>
      )}

      {/* Cycle Phase Guide & Tips (Static Reference) */}
      <div className="mt-4 grid grid-cols-3 gap-2">
        <div className={`p-3 rounded-2xl border flex flex-col gap-1 transition-opacity ${selectedDayStatus !== 'none' && selectedDayStatus !== 'period' ? 'opacity-50' : 'opacity-100'} ${isDarkMode ? 'bg-pink-900/10 border-pink-500/10' : 'bg-pink-50/50 border-pink-100'}`}>
           <div className="flex items-center gap-1.5">
             <div className="w-2 h-2 rounded-full bg-pink-500 shadow-sm" />
             <span className={`text-[9px] font-bold uppercase tracking-wider ${isDarkMode ? 'text-pink-300' : 'text-pink-600'}`}>Period</span>
           </div>
           <p className={`text-[9px] leading-tight ${isDarkMode ? 'text-pink-200/70' : 'text-pink-800/70'}`}>Monitor flow & rest.</p>
        </div>
        <div className={`p-3 rounded-2xl border flex flex-col gap-1 transition-opacity ${selectedDayStatus !== 'none' && selectedDayStatus !== 'fertile' ? 'opacity-50' : 'opacity-100'} ${isDarkMode ? 'bg-teal-900/10 border-teal-500/10' : 'bg-teal-50/50 border-teal-100'}`}>
           <div className="flex items-center gap-1.5">
             <div className="w-2 h-2 rounded-full bg-teal-500 shadow-sm" />
             <span className={`text-[9px] font-bold uppercase tracking-wider ${isDarkMode ? 'text-teal-300' : 'text-teal-600'}`}>Fertile</span>
           </div>
           <p className={`text-[9px] leading-tight ${isDarkMode ? 'text-teal-200/70' : 'text-teal-800/70'}`}>High chance of conception.</p>
        </div>
        <div className={`p-3 rounded-2xl border flex flex-col gap-1 transition-opacity ${selectedDayStatus !== 'none' && selectedDayStatus !== 'ovulation' ? 'opacity-50' : 'opacity-100'} ${isDarkMode ? 'bg-purple-900/10 border-purple-500/10' : 'bg-purple-50/50 border-purple-100'}`}>
           <div className="flex items-center gap-1.5">
             <div className="w-2 h-2 rounded-full border-[1.5px] border-purple-500" />
             <span className={`text-[9px] font-bold uppercase tracking-wider ${isDarkMode ? 'text-purple-300' : 'text-purple-600'}`}>Ovulation</span>
           </div>
           <p className={`text-[9px] leading-tight ${isDarkMode ? 'text-purple-200/70' : 'text-purple-800/70'}`}>Peak fertility day.</p>
        </div>
      </div>

      {/* Journal & Summary Section */}
      <div className="mt-6 space-y-4">
        <div className="flex justify-between items-center px-1">
          <h3 className={`text-sm font-bold uppercase tracking-wider ${textSub}`}>Journal & Insights</h3>
          {journalEntries.length > 0 && (
             <button 
               onClick={() => setShowJournalHistory(!showJournalHistory)}
               className={`text-xs font-bold px-3 py-1 rounded-full border transition-colors ${isDarkMode ? 'border-white/10 hover:bg-white/10 text-white' : 'border-gray-200 hover:bg-gray-50 text-gray-700'}`}
             >
               {showJournalHistory ? 'Hide History' : 'View History'}
             </button>
          )}
        </div>

        {/* Gemini Summary Card */}
        {(journalEntries.length > 0 || journalSummary) && (
          <div className={`p-5 rounded-2xl border shadow-sm relative overflow-hidden ${isDarkMode ? 'bg-lavender-900/40 border-white/5' : 'bg-white border-gray-100'}`}>
             <div className="flex justify-between items-start mb-3">
               <div className="flex items-center gap-2">
                 <Sparkles size={16} className="text-purple-500" />
                 <h4 className={`text-sm font-bold ${textMain}`}>Wellness Summary</h4>
               </div>
               <button 
                 onClick={handleGenerateSummary}
                 disabled={isSummarizing}
                 className="text-xs text-purple-500 font-medium hover:underline disabled:opacity-50"
               >
                 {isSummarizing ? 'Analyzing...' : 'Generate New'}
               </button>
             </div>
             
             {isSummarizing ? (
               <div className="flex flex-col items-center justify-center py-4">
                 <Loader2 className="animate-spin text-purple-400 mb-2" />
                 <span className={`text-xs ${textSub}`}>Gemini is reading your journal...</span>
               </div>
             ) : (
               <p className={`text-xs leading-relaxed ${textSub}`}>
                 {journalSummary || "Tap 'Generate New' to get a personalized summary of your recent journal entries and mood trends."}
               </p>
             )}
          </div>
        )}

        {/* Journal History List */}
        {showJournalHistory && (
           <div className={`rounded-2xl border overflow-hidden ${isDarkMode ? 'bg-white/5 border-white/5' : 'bg-gray-50/50 border-gray-100'}`}>
             {journalEntries.length === 0 ? (
               <div className="p-4 text-center">
                 <p className={`text-xs ${textSub}`}>No entries yet. Add a note in the log!</p>
               </div>
             ) : (
               <div className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-gray-200/50'}`}>
                 {journalEntries.slice(0, 5).map(entry => (
                   <div key={entry.id} className="p-4">
                      <div className="flex justify-between items-center mb-1">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-bold uppercase tracking-wider ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                            {entry.date}
                          </span>
                          {entry._pending && <span title="Saved offline"><CloudOff size={10} className="text-amber-500" /></span>}
                        </div>
                      </div>
                      <p className={`text-xs leading-relaxed ${textMain}`}>{entry.content}</p>
                   </div>
                 ))}
               </div>
             )}
           </div>
        )}
      </div>

      {/* 7. Selected Day & Quick Log */}
      <div className="mt-6">
        <div className="flex justify-between items-center mb-3 px-1">
          <h3 className={`text-sm font-bold ${textMain}`}>
            {selectedDay === data.currentDay ? 'Today, ' : ''}Day {selectedDay}
            <span className={`ml-2 px-2 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wide ${isDarkMode ? 'bg-white/10 text-gray-300' : 'bg-gray-100 text-gray-500'}`}>
              {cycleService.getDayStatus(selectedDay, data.totalLength) === 'period' ? 'Period' : 'Log'}
            </span>
          </h3>
        </div>

        {selectedDay === data.currentDay ? (
          <div className={`rounded-2xl border overflow-hidden flex ${isDarkMode ? 'bg-white/5 border-white/5' : 'bg-white border-gray-100'}`}>
            <div className="w-1 bg-pink-400"></div>
            <div className="p-4 flex-1">
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="px-3 py-1 rounded-full bg-pink-100 text-pink-700 text-xs font-medium">{logData.flow} Flow</span>
                {logData.mood.map(m => (
                  <span key={m} className="px-3 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-medium">{m}</span>
                ))}
              </div>
              <div className={`pt-3 border-t flex justify-between items-center ${isDarkMode ? 'border-white/10' : 'border-gray-100'}`}>
                <span className={`text-xs font-medium ${textSub}`}>Logged recently</span>
                <button 
                  onClick={() => setIsLogModalOpen(true)}
                  className={`text-xs font-medium transition-colors hover:opacity-80 text-pink-600`}
                >
                  Edit Log
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className={`p-6 rounded-2xl border border-dashed text-center ${isDarkMode ? 'border-white/10 bg-white/5' : 'border-gray-200 bg-gray-50'}`}>
            <p className={`text-xs ${textSub}`}>No logs for this date.</p>
          </div>
        )}

        <div className="mt-6">
          <h4 className={`text-[10px] font-bold uppercase tracking-widest mb-3 ${textSub}`}>Quick Add</h4>
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-6 px-6">
            {[
              { label: 'Flow', icon: Droplets, color: '#EC4899', type: 'flow', value: 'Medium' },
              { label: 'Cramps', icon: Activity, color: '#F97316', type: 'symptom', value: 'Cramps' },
              { label: 'Happy', icon: Smile, color: '#EAB308', type: 'mood', value: 'Happy' },
              { label: 'Sad', icon: Frown, color: '#3B82F6', type: 'mood', value: 'Sad' },
            ].map((item, i) => (
              <button
                key={i}
                onClick={() => handleQuickAdd(item.type as any, item.value)}
                className={`flex flex-col items-center gap-2 p-3 min-w-[72px] rounded-xl border transition-all active:scale-95 ${isDarkMode ? 'bg-lavender-900 border-white/5 shadow-none' : 'bg-white border-gray-100 shadow-sm'}`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center shadow-sm" style={{ backgroundColor: isDarkMode ? 'rgba(255,255,255,0.05)' : '#F9FAFB' }}>
                  <item.icon size={16} color={item.color} />
                </div>
                <span className={`text-[10px] font-medium ${textSub}`}>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cycle Config Modal */}
      {isConfigModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in px-4">
            <div className={`w-full max-w-sm rounded-3xl p-6 shadow-2xl animate-slide-up ${isDarkMode ? 'bg-lavender-950 text-white' : 'bg-white text-gray-800'}`}>
                <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-lg">Cycle Settings</h3>
                    <button onClick={() => setIsConfigModalOpen(false)}><X size={20} className={textSub} /></button>
                </div>
                
                <div className="space-y-4">
                    <div className="space-y-2">
                        <label className={`text-xs font-bold uppercase tracking-wide ${textSub}`}>Last Period Start Date</label>
                        <div className="relative">
                            <Calendar className={`absolute left-3 top-3 ${textSub}`} size={16} />
                            <input 
                                type="date" 
                                value={editStartDate}
                                onChange={(e) => setEditStartDate(e.target.value)}
                                className={`w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none border focus:ring-2 focus:ring-pink-500 ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200'}`}
                            />
                        </div>
                    </div>
                    
                    <div className="space-y-2">
                        <label className={`text-xs font-bold uppercase tracking-wide ${textSub}`}>Cycle Length (Days)</label>
                        <input 
                            type="number" 
                            value={editLength}
                            onChange={(e) => setEditLength(e.target.value)}
                            className={`w-full px-4 py-3 rounded-xl text-sm outline-none border focus:ring-2 focus:ring-pink-500 ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200'}`}
                        />
                    </div>
                </div>

                <button 
                    onClick={handleUpdateConfig}
                    className="w-full mt-6 py-3 rounded-xl font-bold bg-pink-500 text-white shadow-lg shadow-pink-500/30"
                >
                    Update Cycle
                </button>
            </div>
        </div>
      )}

      {/* Log Modal */}
      {isLogModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
          <div 
            className={`w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl animate-slide-up overflow-hidden ${isDarkMode ? 'bg-lavender-950 text-white' : 'bg-white text-gray-800'}`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className={`flex justify-between items-center p-6 border-b ${isDarkMode ? 'border-white/10' : 'border-gray-100'}`}>
              <div>
                <h3 className="text-xl font-bold">Log Details</h3>
                <p className={`text-xs mt-1 ${textSub}`}>Day {selectedDay}</p>
              </div>
              <button onClick={() => setIsLogModalOpen(false)} className={`p-2 rounded-full hover:bg-black/5 ${isDarkMode ? 'hover:bg-white/10' : ''}`}>
                <X size={24} className={textSub} />
              </button>
            </div>

            <div className="p-6 space-y-8 max-h-[70vh] overflow-y-auto">
              {/* Flow */}
              <div className="space-y-3">
                <label className={`text-xs font-bold uppercase tracking-wider ${textSub}`}>Menstrual Flow</label>
                <div className={`flex p-1 rounded-xl ${isDarkMode ? 'bg-white/5' : 'bg-gray-100'}`}>
                  {['None', 'Light', 'Medium', 'Heavy'].map(opt => (
                    <button
                      key={opt}
                      onClick={() => setLogData({...logData, flow: opt})}
                      className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${logData.flow === opt ? 'bg-pink-500 text-white shadow-md' : (isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-800')}`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Journal */}
              <div className="space-y-3">
                <label className={`text-xs font-bold uppercase tracking-wider ${textSub}`}>Journal Note</label>
                <textarea
                  value={logData.note}
                  onChange={(e) => setLogData({...logData, note: e.target.value})}
                  placeholder="How are you feeling today?"
                  className={`w-full p-4 rounded-xl text-sm outline-none border focus:ring-2 focus:ring-pink-300 min-h-[100px] resize-none ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-50 border-gray-200 text-gray-800'}`}
                />
              </div>

              <button
                onClick={handleSaveLog}
                className="w-full py-4 rounded-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg flex items-center justify-center gap-2"
              >
                <Save size={18} /> Save Entry
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
