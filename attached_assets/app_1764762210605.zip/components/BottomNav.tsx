import React from 'react';
import { Home, Activity, ShoppingBag, Baby, User } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';

interface BottomNavProps {
  isDarkMode: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({ isDarkMode }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const currentPath = location.pathname;

  const navItems = [
    { id: 'home', path: '/home', icon: Home, label: 'Home' },
    { id: 'cycle', path: '/cycle', icon: Activity, label: 'Cycle' },
    { id: 'shop', path: '/shop', icon: ShoppingBag, label: 'Shop' },
    { id: 'mom', path: '/mom', icon: Baby, label: 'Mom' },
    { id: 'me', path: '/me', icon: User, label: 'Me' },
  ];

  const isActiveTab = (path: string) => {
    // Exact match or sub-route match (except home/root logic)
    if (path === '/shop' && currentPath.includes('/merchant/')) return true;
    return currentPath === path;
  };

  return (
    <div className={`fixed bottom-0 left-0 right-0 border-t pb-safe pt-2 px-6 z-50 transition-all duration-500 ${isDarkMode ? 'glass-panel-dark border-white/10' : 'glass-panel border-white/50'}`}>
      <div className="flex justify-between items-end pb-4">
        {navItems.map((item) => {
          const isActive = isActiveTab(item.path);
          const Icon = item.icon;
          
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center gap-1 group w-12"
            >
              <div className={`p-2 rounded-2xl transition-all duration-300 ${
                isActive 
                  ? (isDarkMode ? 'bg-night-deep text-night-text shadow-lg shadow-black/20 -translate-y-2' : 'bg-purple-50 text-purple-600 -translate-y-2 shadow-lg shadow-purple-100/50') 
                  : (isDarkMode ? 'text-gray-500 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600')
              }`}>
                <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span className={`text-[10px] font-medium transition-colors tracking-wide ${
                isActive 
                  ? (isDarkMode ? 'text-night-text' : 'text-purple-600') 
                  : (isDarkMode ? 'text-gray-600' : 'text-gray-400')
              }`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};