
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Shield, CheckCircle, XCircle, Search, User as UserIcon, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { User } from '../types';
import { api } from '../services/api';

interface AdminPanelProps {
  isDarkMode: boolean;
  currentUser: User;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ isDarkMode, currentUser }) => {
  const navigate = useNavigate();
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const textMain = isDarkMode ? 'text-white' : 'text-gray-800';
  const textSub = isDarkMode ? 'text-gray-400' : 'text-gray-500';
  const cardBg = isDarkMode ? 'bg-lavender-900/40 border-white/10' : 'bg-white/60 border-gray-100';

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const data = await api.getUsers();
        setUsers(data);
      } catch (error) {
        console.error("Failed to load users", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleRoleToggle = async (userId: string) => {
    // Prevent self-demotion
    if (userId === currentUser.id) {
      alert("You cannot demote yourself.");
      return;
    }

    const userToUpdate = users.find(u => u.id === userId);
    if (!userToUpdate) return;

    const newRole = userToUpdate.role === 'admin' ? 'user' : 'admin';
    
    // Optimistic UI Update
    setUsers(users.map(u => {
      if (u.id === userId) {
        return { ...u, role: newRole };
      }
      return u;
    }));

    try {
      await api.updateUser({ ...userToUpdate, role: newRole });
    } catch (error) {
      // Revert if API fails
      console.error("Failed to update role", error);
      setUsers(users.map(u => {
        if (u.id === userId) {
          return { ...u, role: userToUpdate.role };
        }
        return u;
      }));
      alert("Failed to update user role.");
    }
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="pb-24 animate-fade-in min-h-screen">
      <div className={`sticky top-0 z-30 px-6 py-4 border-b backdrop-blur-xl flex items-center gap-3 transition-colors ${isDarkMode ? 'bg-lavender-950/80 border-white/5' : 'bg-white/80 border-gray-100'}`}>
        <button 
          onClick={() => navigate(-1)}
          className={`p-2 rounded-full hover:bg-black/5 transition-colors ${textMain}`}
        >
          <ArrowLeft size={20} />
        </button>
        <h2 className={`text-lg font-bold ${textMain}`}>Admin Dashboard</h2>
      </div>

      <div className="p-6 space-y-6">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-24">
            <Loader2 className="animate-spin text-pink-500 mb-2" size={32} />
            <p className={`text-sm font-medium ${textSub}`}>Accessing User Directory...</p>
          </div>
        ) : (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-2 gap-4">
              <div className={`p-5 rounded-2xl border backdrop-blur-sm ${cardBg}`}>
                <h3 className={`text-[10px] font-bold uppercase tracking-widest mb-2 ${textSub}`}>Total Users</h3>
                <p className={`text-3xl font-bold ${textMain}`}>{users.length}</p>
              </div>
              <div className={`p-5 rounded-2xl border backdrop-blur-sm ${cardBg}`}>
                <h3 className={`text-[10px] font-bold uppercase tracking-widest mb-2 ${textSub}`}>Admins</h3>
                <p className={`text-3xl font-bold text-pink-500`}>{users.filter(u => u.role === 'admin').length}</p>
              </div>
            </div>

            {/* User Management */}
            <div>
              <h3 className={`text-xs font-bold uppercase tracking-widest mb-4 px-1 ${textSub}`}>User Management</h3>
              
              <div className="relative mb-4 group">
                <Search className={`absolute left-3 top-3 transition-colors ${isDarkMode ? 'text-gray-500 group-focus-within:text-pink-400' : 'text-gray-400 group-focus-within:text-pink-500'}`} size={16} />
                <input 
                  type="text" 
                  placeholder="Search by name or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-pink-500/50 transition-all ${isDarkMode ? 'bg-white/5 text-white border border-white/10 focus:bg-white/10' : 'bg-white text-gray-800 border border-gray-200 focus:bg-white'}`}
                />
              </div>

              <div className={`rounded-3xl border overflow-hidden backdrop-blur-md ${cardBg}`}>
                <ul className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-gray-50'}`}>
                  {filteredUsers.map(user => (
                    <li key={user.id} className={`p-4 flex items-center justify-between transition-colors ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-white/40'}`}>
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold overflow-hidden border ${
                          user.role === 'admin' 
                            ? 'bg-gradient-to-br from-pink-100 to-purple-100 text-pink-600 border-pink-200' 
                            : (isDarkMode ? 'bg-white/5 text-gray-400 border-white/10' : 'bg-gray-50 text-gray-500 border-gray-100')
                        }`}>
                          {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : user.name.charAt(0)}
                        </div>
                        <div>
                          <p className={`text-sm font-semibold ${textMain}`}>
                            {user.name} 
                            {user.id === currentUser.id && <span className="text-xs text-pink-500 font-medium ml-2">(You)</span>}
                          </p>
                          <p className={`text-xs ${textSub}`}>{user.email}</p>
                        </div>
                      </div>
                      
                      <button 
                        onClick={() => handleRoleToggle(user.id)}
                        className={`relative px-3 py-1.5 rounded-full text-xs font-bold transition-all duration-300 ${
                          user.role === 'admin' 
                            ? 'bg-pink-500 text-white shadow-lg shadow-pink-500/20 pr-8' 
                            : (isDarkMode ? 'bg-white/5 text-gray-400 hover:bg-white/10 pl-8' : 'bg-gray-100 text-gray-500 hover:bg-gray-200 pl-8')
                        }`}
                      >
                        {user.role === 'admin' && <div className="absolute right-1 top-1 w-4 h-4 bg-white/20 rounded-full animate-pulse" />}
                        {user.role === 'admin' ? 'Admin' : 'User'}
                        {/* Status Dot Indicator */}
                        <div className={`absolute top-1.5 w-4 h-4 rounded-full shadow-sm transition-all duration-300 ${
                            user.role === 'admin' 
                            ? 'right-1.5 bg-white' 
                            : 'left-1.5 bg-white'
                        }`} />
                      </button>
                    </li>
                  ))}
                  {filteredUsers.length === 0 && (
                    <li className="p-8 text-center text-sm text-gray-500">
                      No users found.
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
    