
import React, { useState } from 'react';
import { Search, FileUp, Pill, ChevronRight, Sprout, Map as MapIcon, List, X, Navigation } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { MATERNAL_PRODUCTS_DATA, MOCK_MERCHANTS } from '../constants';
import { FacilityCard } from './FacilityCard';
import { Product, Merchant } from '../types';
import { GentleMap } from './GentleMap'; 

interface MaternalScreenProps {
  isDarkMode: boolean;
  onUploadClick: () => void;
}

export const MaternalScreen: React.FC<MaternalScreenProps> = ({ isDarkMode, onUploadClick }) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [previewMerchant, setPreviewMerchant] = useState<Merchant | null>(null);

  const filters = ['All', 'Vitamins', 'Pain Relief', 'Supplements'];

  // Filter Logic
  const filteredProducts = MATERNAL_PRODUCTS_DATA.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = activeFilter === 'All' 
      ? true 
      : (activeFilter === 'Vitamins' ? p.name.includes('Folic') || p.name.includes('Iron') : true); // Simple mock logic
    return matchesSearch && matchesFilter;
  });

  // Styles
  const textMain = isDarkMode ? 'text-white' : 'text-gray-800';
  const textSub = isDarkMode ? 'text-gray-400' : 'text-gray-500';
  const glassPanel = isDarkMode ? 'bg-lavender-900/40 border-white/10' : 'bg-white/60 border-gray-100';
  const uploadBg = isDarkMode ? 'bg-white/5 border-gray-600 hover:bg-white/10' : 'bg-gray-50 border-gray-300 hover:bg-gray-100';

  if (selectedProduct) {
    // Reusing the Facility Card logic for detail view
    const relevantMerchants = MOCK_MERCHANTS.filter(m => m.stock[selectedProduct.id] !== undefined);
    
    return (
      <div className="space-y-4 animate-slide-up pb-20">
        <div className="flex justify-between items-center mb-4">
           <button 
             onClick={() => setSelectedProduct(null)}
             className={`text-sm font-semibold hover:underline ${textMain}`}
           >
             &larr; Back to Medicines
           </button>
           
           {/* Map Toggle */}
           <div className={`p-1 rounded-lg flex ${isDarkMode ? 'bg-white/10' : 'bg-gray-100'}`}>
              <button
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-md transition-all ${viewMode === 'list' ? 'bg-white shadow-sm' : ''} ${isDarkMode && viewMode === 'list' ? 'text-black' : ''}`}
              >
                <List size={14} />
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`p-1.5 rounded-md transition-all ${viewMode === 'map' ? 'bg-white shadow-sm' : ''} ${isDarkMode && viewMode === 'map' ? 'text-black' : ''}`}
              >
                <MapIcon size={14} />
              </button>
           </div>
        </div>

        <div className={`p-4 rounded-xl flex justify-between items-start ${isDarkMode ? 'bg-white/5' : 'bg-teal-50/50'}`}>
           <div>
             <h3 className={`font-bold ${textMain}`}>{selectedProduct.name}</h3>
             <p className={`text-xs ${textSub}`}>{selectedProduct.description}</p>
           </div>
           <div className={`text-sm font-bold ${isDarkMode ? 'text-teal-400' : 'text-teal-700'}`}>
             {selectedProduct.price.toLocaleString()} RWF
           </div>
        </div>
        
        <h4 className={`text-xs font-bold uppercase tracking-wider mb-2 ${textSub}`}>Available At</h4>
        
        {viewMode === 'map' ? (
          <div className="relative w-full aspect-square rounded-2xl overflow-hidden shadow-inner border border-white/10">
            <GentleMap 
              merchants={relevantMerchants} 
              isDarkMode={isDarkMode} 
              onMarkerClick={(m) => setPreviewMerchant(m)}
            />

            {/* Merchant Summary Slide-up Card */}
            {previewMerchant && (
              <div className="absolute bottom-4 left-4 right-4 z-10 animate-slide-up">
                <div className={`p-4 rounded-2xl shadow-xl backdrop-blur-xl border ${isDarkMode ? 'bg-lavender-950/90 border-white/10 text-white' : 'bg-white/95 border-white/50 text-gray-800'}`}>
                    <div className="flex justify-between items-start mb-2">
                        <div>
                            <h3 className="font-bold text-sm">{previewMerchant.name}</h3>
                            <p className="text-xs opacity-70 mt-0.5">{previewMerchant.type} • {previewMerchant.distance} away</p>
                        </div>
                        <button onClick={() => setPreviewMerchant(null)} className="p-1 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"><X size={16}/></button>
                    </div>
                    <div className="flex gap-2 mt-3">
                        <button onClick={() => navigate(`/merchant/${previewMerchant.id}`)} className="flex-1 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-lg shadow-teal-500/30 transition-all">
                          View Details
                        </button>
                        <button className={`flex-1 py-2.5 border rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${isDarkMode ? 'border-white/20 hover:bg-white/5' : 'border-gray-200 hover:bg-gray-50'}`}>
                          <Navigation size={12} /> Directions
                        </button>
                    </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          relevantMerchants.length > 0 ? (
            relevantMerchants.map((merchant, index) => (
              <div 
                key={merchant.id} 
                className="animate-fade-in" 
                style={{ animationDelay: `${index * 100}ms`, animationFillMode: 'both' }}
              >
                <FacilityCard 
                  merchant={merchant} 
                  productId={selectedProduct.id} 
                  isDarkMode={isDarkMode}
                  onClick={() => navigate(`/merchant/${merchant.id}`)}
                />
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center animate-fade-in">
              <div className={`w-28 h-28 rounded-full flex items-center justify-center mb-5 ${isDarkMode ? 'bg-white/5' : 'bg-gradient-to-tr from-teal-50 to-pink-50'}`}>
                  <Sprout size={48} className={isDarkMode ? 'text-teal-400' : 'text-teal-600'} strokeWidth={1} />
              </div>
              <h3 className={`font-bold text-lg mb-2 ${textMain}`}>Community Growing</h3>
              <p className={`text-sm max-w-[220px] leading-relaxed ${textSub}`}>
                No pharmacy partners nearby with this medication yet.
              </p>
            </div>
          )
        )}
      </div>
    );
  }

  return (
    <div className="pb-24 animate-fade-in space-y-6">
      
      {/* 2. Page Header */}
      <div className="flex justify-between items-start">
        <div>
          <h2 className={`text-xl font-bold ${textMain}`}>Maternal & ANC</h2>
          <p className={`text-sm ${textSub}`}>Access essential medicines.</p>
        </div>
        <button className={`p-1 px-3 rounded-lg text-xs font-medium border ${isDarkMode ? 'border-teal-400/30 text-teal-400' : 'border-teal-100 text-teal-600 bg-teal-50'}`}>
          Sort
        </button>
      </div>

      {/* 3. Search & Filter Bar */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search medicines..."
            className={`w-full py-2 pl-10 pr-4 rounded-xl text-sm outline-none focus:ring-1 focus:ring-teal-500 transition-all ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-white border-gray-200 text-gray-800'}`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors border ${
                activeFilter === f 
                  ? 'bg-teal-600 text-white border-teal-600' 
                  : (isDarkMode ? 'bg-transparent text-gray-400 border-white/10' : 'bg-white text-gray-600 border-gray-200')
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* 4. Upload Prescription Widget */}
      <div 
        onClick={onUploadClick}
        className={`group relative rounded-2xl border-2 border-dashed p-6 cursor-pointer transition-all duration-300 ${uploadBg}`}
      >
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm transition-transform duration-300 group-hover:scale-110 ${isDarkMode ? 'bg-lavender-900' : 'bg-white'}`}>
            <FileUp size={24} className="text-pink-500" />
          </div>
          <div>
            <h3 className={`text-sm font-medium ${isDarkMode ? 'text-gray-200' : 'text-gray-700'}`}>
              Upload Prescription
            </h3>
            <p className="text-xs text-gray-500 mt-1 max-w-[200px] leading-snug">
              Take a photo of your doctor's note to find pharmacies with stock.
            </p>
          </div>
        </div>
      </div>

      {/* 5. Category Listing */}
      <div>
        <div className="flex items-center gap-2 mb-3 px-1">
          <Pill size={16} className="text-teal-600" />
          <h3 className={`text-sm font-bold ${textMain}`}>Browse Medicines</h3>
        </div>

        <div className="space-y-2">
          <h4 className={`text-[10px] font-bold uppercase tracking-wider px-1 ${textSub}`}>
            Essentials
          </h4>
          
          <div className={`rounded-xl border overflow-hidden ${glassPanel}`}>
            <ul className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-gray-50'}`}>
              {filteredProducts.map((product, index) => (
                <li 
                  key={product.id}
                  onClick={() => setSelectedProduct(product)}
                  className={`p-4 flex items-center justify-between cursor-pointer group transition-all duration-200 ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-white'}`}
                >
                  <div>
                    <h4 className={`text-sm font-medium transition-colors ${textMain} group-hover:text-teal-600`}>
                      {product.name}
                    </h4>
                    <p className={`text-[10px] mt-0.5 ${textSub}`}>
                      {product.description}
                    </p>
                  </div>
                  <ChevronRight size={16} className={isDarkMode ? 'text-gray-600' : 'text-gray-300'} />
                </li>
              ))}
              {filteredProducts.length === 0 && (
                 <div className="flex flex-col items-center justify-center py-12 text-center animate-fade-in">
                    <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${isDarkMode ? 'bg-white/5' : 'bg-gray-50'}`}>
                      <Sprout size={32} className={`opacity-50 ${isDarkMode ? 'text-teal-400' : 'text-teal-600'}`} />
                    </div>
                    <p className={`text-sm ${textSub}`}>No medicines match your search.</p>
                 </div>
              )}
            </ul>
          </div>
        </div>
      </div>

    </div>
  );
};
