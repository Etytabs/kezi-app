const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const PRODUCTS_DATA = [
  { id: 'p_yaz', name: 'Yaz Plus', description: 'Combined oral contraceptive', type: 'Contraceptive', price: 12000, tags: JSON.stringify(['daily', 'hormonal']) },
  { id: 'p_copper', name: 'Copper IUD', description: 'Long-acting reversible contraception', type: 'Contraceptive', price: 2500, tags: JSON.stringify(['long-term']) },
  { id: 'p_condom', name: 'Durex Extra Safe', description: 'Pack of 3 condoms', type: 'Contraceptive', price: 1500, tags: JSON.stringify(['protection', 'ovulation']) },
  { id: 'p_planb', name: 'Morning After Pill', description: 'Emergency contraception', type: 'Contraceptive', price: 5000, tags: JSON.stringify(['emergency']) },
  { id: 'h_always', name: 'Always Ultra', description: 'Sanitary pads (Pack of 8)', type: 'Hygiene', price: 1200, tags: JSON.stringify(['menstrual', 'flow']) },
  { id: 'h_cup', name: 'Menstrual Cup', description: 'Reusable silicone cup (Size M)', type: 'Hygiene', price: 15000, tags: JSON.stringify(['menstrual', 'eco']) },
  { id: 'h_tampon', name: 'Tampax Pearl', description: 'Regular absorbency tampons', type: 'Hygiene', price: 3500, tags: JSON.stringify(['menstrual', 'flow']) },
  { id: 'h_wash', name: 'Intimate Wash', description: 'pH-balanced hygiene wash', type: 'Hygiene', price: 4500, tags: JSON.stringify(['daily', 'care']) },
  { id: 'm_folic', name: 'Folic Acid', description: 'Prenatal supplement (30 tabs)', type: 'Medicine', price: 800, tags: JSON.stringify(['pregnancy']) },
  { id: 'm_iron', name: 'Iron Supplements', description: 'Ferrous Sulfate 200mg', type: 'Medicine', price: 1200, tags: JSON.stringify(['pregnancy', 'anemia']) },
  { id: 'm_para', name: 'Paracetamol', description: 'Pain relief safe for pregnancy', type: 'Medicine', price: 500, tags: JSON.stringify(['pain']) },
  { id: 'm_calcium', name: 'Calcium + D3', description: 'Bone health support', type: 'Medicine', price: 2500, tags: JSON.stringify(['pregnancy']) },
  { id: 'm_kit', name: 'Clean Delivery Kit', description: 'Sterile birthing essentials', type: 'Medicine', price: 4500, tags: JSON.stringify(['birth']) },
];

const MERCHANTS_DATA = [
  { 
    id: '1', 
    name: 'Kigali Life Care', 
    address: 'KG 14 Ave',
    distance: '0.4 km', 
    latitude: -1.9441,
    longitude: 30.0619,
    type: 'Pharmacy',
    stock: { 'p_yaz': 45, 'p_condom': 120, 'h_always': 0, 'h_cup': 5, 'm_folic': 50, 'm_iron': 30 } 
  },
  { 
    id: '2', 
    name: 'City Center Clinic', 
    address: 'Downtown Main St',
    distance: '1.2 km', 
    latitude: -1.9350,
    longitude: 30.0580,
    type: 'Clinic',
    stock: { 'p_copper': 10, 'p_planb': 5, 'h_tampon': 50, 'm_kit': 10 } 
  },
  { 
    id: '3', 
    name: 'Nyamirambo Health', 
    address: 'KN 2 St',
    distance: '2.5 km', 
    latitude: -1.9600,
    longitude: 30.0500,
    type: 'Pharmacy',
    stock: { 'p_yaz': 2, 'h_always': 200, 'h_wash': 15, 'm_para': 100 } 
  },
  { 
    id: '4', 
    name: 'SafeFlow Dispenser', 
    address: 'University Campus',
    distance: '0.1 km', 
    latitude: -1.9480,
    longitude: 30.0700,
    type: 'Dispenser',
    stock: { 'h_always': 15, 'p_condom': 30 } 
  },
];

async function main() {
  console.log('Start seeding ...');
  
  // Seed Products
  for (const p of PRODUCTS_DATA) {
    await prisma.product.upsert({
      where: { id: p.id },
      update: {},
      create: p,
    });
  }

  // Seed Merchants and Stock
  for (const m of MERCHANTS_DATA) {
    const merchant = await prisma.merchant.upsert({
      where: { id: m.id },
      update: {},
      create: {
        id: m.id,
        name: m.name,
        address: m.address,
        distance: m.distance,
        latitude: m.latitude,
        longitude: m.longitude,
        type: m.type
      }
    });

    // Seed Stock
    for (const [productId, count] of Object.entries(m.stock)) {
      await prisma.stock.upsert({
        where: {
          merchantId_productId: {
            merchantId: merchant.id,
            productId: productId
          }
        },
        update: { count },
        create: {
          merchantId: merchant.id,
          productId: productId,
          count
        }
      });
    }
  }

  console.log('Seeding finished.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });