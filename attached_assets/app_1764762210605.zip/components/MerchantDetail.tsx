import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, Phone, Clock, Sprout, Star, User } from 'lucide-react';
import { MOCK_MERCHANTS, PRODUCTS_DATA, MATERNAL_PRODUCTS_DATA, MOCK_REVIEWS } from '../constants';
import { FacilitySkeleton } from './SkeletonLoader';

interface MerchantDetailProps {
  isDarkMode: boolean;
}

export const MerchantDetail: React.FC<MerchantDetailProps> = ({ isDarkMode }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const merchant = MOCK_MERCHANTS.find(m => m.id === id);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);

  const textMain = isDarkMode ? 'text-white' : 'text-gray-800';
  const textSub = isDarkMode ? 'text-gray-400' : 'text-gray-500';
  const bgCard = isDarkMode ? 'bg-lavender-900/50 border-white/5' : 'bg-white border-gray-100';

  if (!merchant && !loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen text-center animate-fade-in p-6 pb-24">
        <div className={`w-28 h-28 rounded-full flex items-center justify-center mb-5 ${isDarkMode ? 'bg-white/5' : 'bg-gradient-to-tr from-pink-50 to-purple-50'}`}>
          <Sprout size={48} className={isDarkMode ? 'text-purple-400' : 'text-purple-500'} strokeWidth={1} />
        </div>
        <h3 className={`font-bold text-lg mb-2 ${textMain}`}>Merchant Not Found</h3>
        <p className={`text-sm max-w-[240px] leading-relaxed mb-6 ${textSub}`}>
          We couldn't locate this facility. It may have moved or is temporarily unavailable in our network.
        </p>
        <button 
          onClick={() => navigate(-1)}
          className={`px-6 py-3 rounded-xl font-semibold transition-colors shadow-sm ${isDarkMode ? 'bg-white/10 text-white hover:bg-white/20' : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'}`}
        >
          Return to Previous
        </button>
      </div>
    );
  }

  // Combine products for lookup
  const allProducts = [...PRODUCTS_DATA, ...MATERNAL_PRODUCTS_DATA];
  
  // Get in-stock items
  const stockItems = merchant ? Object.entries(merchant.stock).map(([pid, count]) => {
    const product = allProducts.find(p => p.id === pid);
    return { product, count };
  }).filter(item => item.product) : [];

  // Get Reviews
  const reviews = MOCK_REVIEWS.filter(r => r.merchantId === id);

  return (
    <div className="pb-24 animate-fade-in min-h-screen">
      {/* Header */}
      <div className={`sticky top-0 z-30 px-6 py-4 border-b backdrop-blur-md flex items-center gap-3 ${isDarkMode ? 'bg-lavender-950/90 border-white/5' : 'bg-white/90 border-gray-100'}`}>
        <button 
          onClick={() => navigate(-1)}
          className={`p-2 rounded-full hover:bg-black/5 transition-colors ${textMain}`}
        >
          <ArrowLeft size={20} />
        </button>
        <h2 className={`text-lg font-bold ${textMain}`}>{merchant?.name || 'Loading...'}</h2>
      </div>

      {loading ? (
        <div className="p-6 space-y-6">
           <FacilitySkeleton isDarkMode={isDarkMode} />
           <FacilitySkeleton isDarkMode={isDarkMode} />
        </div>
      ) : merchant && (
        /* Info Card */
        <div className="p-6 space-y-6">
          <div className={`p-5 rounded-2xl border shadow-sm ${bgCard}`}>
            <div className="flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <MapPin className={`mt-0.5 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} size={18} />
                <div>
                  <p className={`text-sm font-medium ${textMain}`}>{merchant.address}</p>
                  <p className={`text-xs ${textSub}`}>{merchant.distance} away</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className={`mt-0.5 ${isDarkMode ? 'text-teal-400' : 'text-teal-600'}`} size={18} />
                <p className={`text-sm ${textMain}`}>Open until 9:00 PM</p>
              </div>
              <div className="flex gap-3 mt-2">
                <button className="flex-1 py-2 rounded-xl bg-emerald-100 text-emerald-800 text-sm font-semibold hover:bg-emerald-200 transition-colors">
                  Call Now
                </button>
                <button className="flex-1 py-2 rounded-xl border border-gray-200 text-gray-700 text-sm font-semibold hover:bg-gray-50 transition-colors">
                  Directions
                </button>
              </div>
            </div>
          </div>

          {/* Reviews Section */}
          <div>
            <div className="flex items-center justify-between mb-3 px-1">
              <h3 className={`text-sm font-bold uppercase tracking-wider ${textSub}`}>Reviews</h3>
              <div className="flex items-center gap-1">
                 <Star size={14} className="text-amber-400 fill-amber-400" />
                 <span className={`text-sm font-bold ${textMain}`}>4.8</span>
                 <span className={`text-xs ${textSub}`}>(120)</span>
              </div>
            </div>
            
            <div className={`rounded-2xl border overflow-hidden ${bgCard}`}>
               {reviews.length > 0 ? (
                 <div className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-gray-50'}`}>
                   {reviews.map(review => (
                     <div key={review.id} className="p-4">
                       <div className="flex justify-between items-start mb-2">
                         <div className="flex items-center gap-2">
                           <div className={`w-8 h-8 rounded-full flex items-center justify-center overflow-hidden ${isDarkMode ? 'bg-white/10' : 'bg-gray-100 text-gray-500'}`}>
                             {review.avatar ? (
                               <img src={review.avatar} alt={review.userName} className="w-full h-full object-cover" />
                             ) : (
                               <User size={14} />
                             )}
                           </div>
                           <div>
                             <span className={`text-sm font-semibold block ${textMain}`}>{review.userName}</span>
                             <div className="flex items-center gap-1">
                              {[1, 2, 3, 4, 5].map(star => (
                                <Star 
                                  key={star} 
                                  size={10} 
                                  className={star <= review.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'} 
                                />
                              ))}
                            </div>
                           </div>
                         </div>
                         <span className={`text-[10px] ${textSub}`}>{review.date}</span>
                       </div>
                       
                       <p className={`text-xs leading-relaxed italic mb-2 ${textSub}`}>"{review.comment}"</p>
                       
                       {/* Photo Review */}
                       {review.imageUrl && (
                         <div className="mt-2 rounded-lg overflow-hidden h-24 w-32 relative group cursor-pointer">
                           <img src={review.imageUrl} alt="Review" className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                           <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
                         </div>
                       )}
                     </div>
                   ))}
                 </div>
               ) : (
                 <div className="p-6 text-center">
                   <p className={`text-xs ${textSub}`}>No reviews yet.</p>
                 </div>
               )}
            </div>
          </div>

          {/* Stock List */}
          <div>
            <h3 className={`text-sm font-bold uppercase tracking-wider mb-3 px-1 ${textSub}`}>Current Stock</h3>
            <div className={`rounded-2xl border overflow-hidden ${bgCard}`}>
              <ul className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-gray-50'}`}>
                {stockItems.map(({ product, count }) => {
                  let stockText = 'Out of Stock';
                  let stockColorClass = 'text-red-500';

                  if (count > 10) {
                    stockText = 'In Stock';
                    stockColorClass = 'text-emerald-600';
                  } else if (count > 0) {
                    stockText = `Low Stock (${count})`;
                    stockColorClass = 'text-amber-600';
                  }

                  return (
                    <li key={product!.id} className="p-4 flex justify-between items-center">
                      <div>
                        <h4 className={`text-sm font-medium ${textMain}`}>{product!.name}</h4>
                        <p className={`text-xs ${textSub}`}>{product!.type}</p>
                      </div>
                      <div className={`text-sm font-bold ${stockColorClass}`}>
                        {stockText}
                      </div>
                    </li>
                  );
                })}
                {stockItems.length === 0 && (
                  <li className="p-8 flex flex-col items-center justify-center text-center">
                      <Sprout size={32} className={`mb-2 opacity-50 ${textSub}`} />
                      <p className={`text-sm ${textSub}`}>No stock info currently available.</p>
                  </li>
                )}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};