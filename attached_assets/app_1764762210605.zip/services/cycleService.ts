
import { CyclePhase } from "../types";

/**
 * Cycle Logic Extensibility Module
 * 
 * This service encapsulates the biological logic for cycle tracking.
 * It allows for future upgrades (e.g., irregular cycle algorithms) without breaking UI components.
 */
export const cycleService = {
  /**
   * Determines the high-level phase based on the current cycle day.
   */
  calculatePhase: (currentDay: number, totalLength: number = 28): CyclePhase => {
    if (currentDay >= 1 && currentDay <= 5) return CyclePhase.MENSTRUAL;
    // Follicular overlaps with fertile window in this simplified model
    if (currentDay >= 6 && currentDay <= 13) return CyclePhase.FOLLICULAR;
    if (currentDay === 14) return CyclePhase.OVULATION;
    return CyclePhase.LUTEAL;
  },

  /**
   * Returns specific status for calendar visualization and logic.
   * 'period' | 'fertile' | 'ovulation' | 'none'
   */
  getDayStatus: (day: number, totalLength: number = 28): 'period' | 'fertile' | 'ovulation' | 'none' => {
     // Ovulation (Center of standard cycle)
     if (day === 14) return 'ovulation';
     
     // Menstruation (Days 1-5)
     if (day >= 1 && day <= 5) return 'period';
     
     // Fertile Window (Days 11-15)
     if (day >= 11 && day <= 15) return 'fertile';
     
     return 'none';
  },

  /**
   * Provides a human-readable summary of the current status.
   */
  getPhaseDescription: (phase: CyclePhase): string => {
    switch (phase) {
      case CyclePhase.MENSTRUAL: return "Time to rest and recharge.";
      case CyclePhase.FOLLICULAR: return "Energy levels are rising.";
      case CyclePhase.OVULATION: return "Peak fertility window.";
      case CyclePhase.LUTEAL: return "Prepare for the next cycle.";
      default: return "";
    }
  }
};
