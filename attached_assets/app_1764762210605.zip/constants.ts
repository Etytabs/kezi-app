

import { CyclePhase, Merchant, LogItem, Product, InspirationContent, Review, User } from "./types";

export const MOCK_CYCLE_DATA = {
  currentDay: 14,
  totalLength: 28,
  phase: CyclePhase.OVULATION,
  nextPeriodDays: 14,
  startDate: '2025-11-01'
};

export const PRODUCTS_DATA: Product[] = [
  // Contraceptives
  { id: 'p_yaz', name: 'Yaz Plus', description: 'Combined oral contraceptive', type: 'Contraceptive', price: 12000, tags: ['daily', 'hormonal'] },
  { id: 'p_copper', name: 'Copper IUD', description: 'Long-acting reversible contraception', type: 'Contraceptive', price: 2500, tags: ['long-term'] },
  { id: 'p_condom', name: 'Durex Extra Safe', description: 'Pack of 3 condoms', type: 'Contraceptive', price: 1500, tags: ['protection', 'ovulation'] },
  { id: 'p_planb', name: 'Morning After Pill', description: 'Emergency contraception', type: 'Contraceptive', price: 5000, tags: ['emergency'] },
  
  // Hygiene
  { id: 'h_always', name: 'Always Ultra', description: 'Sanitary pads (Pack of 8)', type: 'Hygiene', price: 1200, tags: ['menstrual', 'flow'] },
  { id: 'h_cup', name: 'Menstrual Cup', description: 'Reusable silicone cup (Size M)', type: 'Hygiene', price: 15000, tags: ['menstrual', 'eco'] },
  { id: 'h_tampon', name: 'Tampax Pearl', description: 'Regular absorbency tampons', type: 'Hygiene', price: 3500, tags: ['menstrual', 'flow'] },
  { id: 'h_wash', name: 'Intimate Wash', description: 'pH-balanced hygiene wash', type: 'Hygiene', price: 4500, tags: ['daily', 'care'] },
];

export const MATERNAL_PRODUCTS_DATA: Product[] = [
  { id: 'm_folic', name: 'Folic Acid', description: 'Prenatal supplement (30 tabs)', type: 'Medicine', price: 800, tags: ['pregnancy'] },
  { id: 'm_iron', name: 'Iron Supplements', description: 'Ferrous Sulfate 200mg', type: 'Medicine', price: 1200, tags: ['pregnancy', 'anemia'] },
  { id: 'm_para', name: 'Paracetamol', description: 'Pain relief safe for pregnancy', type: 'Medicine', price: 500, tags: ['pain'] },
  { id: 'm_calcium', name: 'Calcium + D3', description: 'Bone health support', type: 'Medicine', price: 2500, tags: ['pregnancy'] },
  { id: 'm_kit', name: 'Clean Delivery Kit', description: 'Sterile birthing essentials', type: 'Medicine', price: 4500, tags: ['birth'] },
];

// Kigali Center Approx: -1.9441, 30.0619
export const MOCK_MERCHANTS: Merchant[] = [
  { 
    id: '1', 
    name: 'Kigali Life Care', 
    address: 'KG 14 Ave',
    distance: '0.4 km', 
    latitude: -1.9441,
    longitude: 30.0619,
    type: 'Pharmacy',
    stock: { 'p_yaz': 45, 'p_condom': 120, 'h_always': 0, 'h_cup': 5, 'm_folic': 50, 'm_iron': 30 } 
  },
  { 
    id: '2', 
    name: 'City Center Clinic', 
    address: 'Downtown Main St',
    distance: '1.2 km', 
    latitude: -1.9350,
    longitude: 30.0580,
    type: 'Clinic',
    stock: { 'p_copper': 10, 'p_planb': 5, 'h_tampon': 50, 'm_kit': 10 } 
  },
  { 
    id: '3', 
    name: 'Nyamirambo Health', 
    address: 'KN 2 St',
    distance: '2.5 km', 
    latitude: -1.9600,
    longitude: 30.0500,
    type: 'Pharmacy',
    stock: { 'p_yaz': 2, 'h_always': 200, 'h_wash': 15, 'm_para': 100 } 
  },
  { 
    id: '4', 
    name: 'SafeFlow Dispenser', 
    address: 'University Campus',
    distance: '0.1 km', 
    latitude: -1.9480,
    longitude: 30.0700,
    type: 'Dispenser',
    stock: { 'h_always': 15, 'p_condom': 30 } 
  },
];

export const MOCK_REVIEWS: Review[] = [
  { 
    id: 'r1', 
    merchantId: '1', 
    userName: 'Alice K.', 
    rating: 5, 
    comment: 'Very discreet and professional service. They had exactly what I needed.', 
    date: '2 days ago',
    imageUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=200&h=200' 
  },
  { 
    id: 'r2', 
    merchantId: '1', 
    userName: 'Grace M.', 
    rating: 4, 
    comment: 'Good stock, but a bit of a wait.', 
    date: '1 week ago' 
  },
  { 
    id: 'r3', 
    merchantId: '2', 
    userName: 'Chantal U.', 
    rating: 5, 
    comment: 'The nurse was incredibly helpful with my questions. Highly recommended.', 
    date: '3 days ago',
    imageUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200&h=200'
  },
];

export const MOCK_USERS: User[] = [
  { id: 'u_1', name: 'Admin User', email: 'admin@jasmin.app', role: 'admin' },
  { id: 'u_2', name: 'Jane Doe', email: 'jane@example.com', role: 'user' },
  { id: 'u_3', name: 'Sarah Smith', email: 'sarah@example.com', role: 'user' },
  { id: 'u_4', name: 'Merchant Pro', email: 'pharmacy@kigali.rw', role: 'user' },
];

export const PHASE_COLORS = {
  [CyclePhase.MENSTRUAL]: '#EC4899', // Brand Pink (pink-500)
  [CyclePhase.FOLLICULAR]: '#E9D5FF', // Soft Lavender (purple-200) - Transition
  [CyclePhase.OVULATION]: '#9333EA', // Brand Purple (purple-600)
  [CyclePhase.LUTEAL]: '#FBCFE8', // Light Pink (pink-200) - Transition
};

export const SYMPTOMS_LOG: LogItem[] = [
  { id: 'light', label: 'Light Flow', color: '#F472B6' },
  { id: 'medium', label: 'Medium', color: '#EC4899' },
  { id: 'heavy', label: 'Heavy Flow', color: '#DB2777' },
  { id: 'cramps', label: 'Cramps', color: '#F97316' },
];

export const MOOD_LOG: LogItem[] = [
  { id: 'happy', label: 'Happy', color: '#EAB308' },
  { id: 'sad', label: 'Sad', color: '#3B82F6' },
];

export const MOCK_INSPIRATION: InspirationContent[] = [
  {
    id: '1',
    title: 'Rwanda SRH Law',
    body: '"Access to reproductive health services is a fundamental right for all citizens."',
    source: 'Ministry of Health'
  },
  {
    id: '2',
    title: 'WHO Insight',
    body: '"Universal coverage ensures long-term health stability for mothers and children."',
    source: 'WHO'
  },
  {
    id: '3',
    title: 'Wellness Tip',
    body: '"Hydration improves cycle regularity and reduces cramping severity significantly."',
    source: 'Jasmin Team'
  }
];