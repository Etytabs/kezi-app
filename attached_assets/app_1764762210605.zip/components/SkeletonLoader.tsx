import React from 'react';

interface SkeletonProps {
  className?: string;
  isDarkMode?: boolean;
}

export const SkeletonLoader: React.FC<SkeletonProps> = ({ className = '', isDarkMode = false }) => {
  const baseClass = isDarkMode 
    ? 'bg-white/5 border-white/5' 
    : 'bg-white/40 border-white/40';
  
  const shimmerClass = isDarkMode
    ? 'via-white/10'
    : 'via-white/80';

  return (
    <div className={`relative overflow-hidden rounded-xl border ${baseClass} ${className}`}>
      {/* Shimmer Effect */}
      <div 
        className={`absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent ${shimmerClass} to-transparent`} 
        style={{ transform: 'skewX(-20deg)' }}
      />
    </div>
  );
};

export const ProductSkeleton: React.FC<{ isDarkMode: boolean }> = ({ isDarkMode }) => (
  <div className="flex justify-between items-center p-4">
    <div className="space-y-2">
      <SkeletonLoader className="h-4 w-32" isDarkMode={isDarkMode} />
      <SkeletonLoader className="h-3 w-48" isDarkMode={isDarkMode} />
    </div>
    <div className="flex items-center gap-3">
       <SkeletonLoader className="h-4 w-16" isDarkMode={isDarkMode} />
       <SkeletonLoader className="h-4 w-4 rounded-full" isDarkMode={isDarkMode} />
    </div>
  </div>
);

export const FacilitySkeleton: React.FC<{ isDarkMode: boolean }> = ({ isDarkMode }) => (
  <div className="p-4 rounded-xl border border-transparent space-y-3">
    <div className="flex justify-between">
      <div className="space-y-2 flex-1">
        <SkeletonLoader className="h-4 w-40" isDarkMode={isDarkMode} />
        <SkeletonLoader className="h-3 w-24" isDarkMode={isDarkMode} />
        <SkeletonLoader className="h-3 w-20 mt-1" isDarkMode={isDarkMode} />
      </div>
      <div className="flex flex-col items-end gap-2">
         <SkeletonLoader className="h-6 w-16 rounded-full" isDarkMode={isDarkMode} />
         <div className="flex gap-2">
            <SkeletonLoader className="h-6 w-6 rounded-lg" isDarkMode={isDarkMode} />
            <SkeletonLoader className="h-6 w-6 rounded-lg" isDarkMode={isDarkMode} />
         </div>
      </div>
    </div>
  </div>
);
