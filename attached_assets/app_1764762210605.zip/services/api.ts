
import { CycleData, Merchant, User, CyclePhase, JournalEntry, DependentProfile, CycleConfig } from "../types";
import { MOCK_CYCLE_DATA, MOCK_MERCHANTS, MOCK_USERS } from "../constants";
import { cycleService } from "./cycleService";

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const STORAGE_KEYS = {
  TOKEN: 'jasmin_token',
  USER: 'jasmin_user',
  ALL_USERS: 'jasmin_all_users',
  RECENT_SEARCHES: 'jasmin_recent_searches',
  JOURNAL: 'jasmin_journal_entries',
  SYNC_QUEUE: 'jasmin_sync_queue', // Offline Sync Queue
  CYCLE_CONFIG: 'jasmin_cycle_config',
  MERCHANTS: 'jasmin_merchants_store'
};

// In-memory store for session persistence of mock data
let usersStore = [...MOCK_USERS];
let journalStore: JournalEntry[] = [];
let merchantsStore: Merchant[] = [...MOCK_MERCHANTS];

// Initialize data from local storage
try {
  // Load Journal
  const storedJournal = localStorage.getItem(STORAGE_KEYS.JOURNAL);
  if (storedJournal) {
    journalStore = JSON.parse(storedJournal);
  }

  // Load User Directory (for Admin persistence)
  const storedUsers = localStorage.getItem(STORAGE_KEYS.ALL_USERS);
  if (storedUsers) {
    usersStore = JSON.parse(storedUsers);
  }

  // Load Merchants (for Inventory persistence)
  const storedMerchants = localStorage.getItem(STORAGE_KEYS.MERCHANTS);
  if (storedMerchants) {
    merchantsStore = JSON.parse(storedMerchants);
  }
} catch (e) {
  console.error("Failed to load local data", e);
}

interface ViewportBounds {
  north: number;
  south: number;
  east: number;
  west: number;
}

interface SyncAction {
  type: 'JOURNAL_ADD' | 'USER_UPDATE' | 'RESERVE_STOCK';
  payload: any;
  timestamp: number;
}

export const api = {
  // --- Offline Sync Strategy ---
  syncData: async () => {
    const queueStr = localStorage.getItem(STORAGE_KEYS.SYNC_QUEUE);
    if (!queueStr) return;

    const queue: SyncAction[] = JSON.parse(queueStr);
    if (queue.length === 0) return;

    console.log(`[Sync] Processing ${queue.length} offline actions...`);

    // Process queue items (Simulation of sending to server)
    for (const action of queue) {
        await delay(200); // Simulate network overhead per item
        console.log(`[Sync] Processed ${action.type}`, action.payload);
        
        if (action.type === 'JOURNAL_ADD') {
             const entryIndex = journalStore.findIndex(j => j.id === action.payload.id);
             if (entryIndex !== -1) {
                 delete journalStore[entryIndex]._pending;
             }
        }
    }

    // Clear queue after success
    localStorage.removeItem(STORAGE_KEYS.SYNC_QUEUE);
    // Update local storage to remove pending flags if needed
    localStorage.setItem(STORAGE_KEYS.JOURNAL, JSON.stringify(journalStore));
    console.log("[Sync] Complete");
  },

  getCurrentUser: async (): Promise<User | null> => {
    const token = localStorage.getItem(STORAGE_KEYS.TOKEN);
    if (!token) return null;
    
    const storedUser = localStorage.getItem(STORAGE_KEYS.USER);
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      const memoryUser = usersStore.find(u => u.id === parsedUser.id);
      if (memoryUser) {
        if (!memoryUser.profiles) memoryUser.profiles = [];
        if (!memoryUser.activeProfileId) memoryUser.activeProfileId = 'main';
        return memoryUser;
      }
      if (!parsedUser.profiles) parsedUser.profiles = [];
      if (!parsedUser.activeProfileId) parsedUser.activeProfileId = 'main';
      return parsedUser;
    }
    
    // Fallback
    const fallback = usersStore[0];
    if (fallback) {
      if (!fallback.profiles) fallback.profiles = [];
      if (!fallback.activeProfileId) fallback.activeProfileId = 'main';
    }
    return fallback;
  },

  login: async (email: string): Promise<User> => {
    await delay(800); 
    let user = usersStore.find(u => u.email === email);

    if (!user) {
        const role = email === 'admin@jasmin.app' ? 'admin' : 'user';
        user = {
            id: 'u_' + Date.now(),
            name: email.split('@')[0],
            email,
            role,
            wishlist: [],
            recentSearches: [],
            profiles: [],
            activeProfileId: 'main'
        };
        usersStore.push(user);
        localStorage.setItem(STORAGE_KEYS.ALL_USERS, JSON.stringify(usersStore));
    }

    localStorage.setItem(STORAGE_KEYS.TOKEN, 'mock_jwt_token_header.payload.signature');
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
    return user;
  },

  logout: async () => {
    localStorage.removeItem(STORAGE_KEYS.TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER);
  },

  getUsers: async (): Promise<User[]> => {
    await delay(600);
    return [...usersStore];
  },

  updateUser: async (user: User): Promise<User> => {
    await delay(600);
    
    const index = usersStore.findIndex(u => u.id === user.id);
    if (index !== -1) {
        usersStore[index] = user;
    } else {
        usersStore.push(user);
    }
    
    localStorage.setItem(STORAGE_KEYS.ALL_USERS, JSON.stringify(usersStore));

    const storedUserStr = localStorage.getItem(STORAGE_KEYS.USER);
    if (storedUserStr) {
        const storedUser = JSON.parse(storedUserStr);
        if (storedUser.id === user.id) {
            localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
        }
    }
    
    return user;
  },

  addDependentProfile: async (userId: string, profile: Omit<DependentProfile, 'id'>): Promise<User> => {
    await delay(400);
    const userIndex = usersStore.findIndex(u => u.id === userId);
    if (userIndex === -1) throw new Error("User not found");

    const newProfile: DependentProfile = {
      ...profile,
      id: `p_${Date.now()}`
    };

    const updatedUser = { ...usersStore[userIndex] };
    if (!updatedUser.profiles) updatedUser.profiles = [];
    updatedUser.profiles.push(newProfile);
    updatedUser.activeProfileId = newProfile.id;

    usersStore[userIndex] = updatedUser;
    localStorage.setItem(STORAGE_KEYS.ALL_USERS, JSON.stringify(usersStore));
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedUser));
    
    return updatedUser;
  },

  switchActiveProfile: async (userId: string, profileId: string): Promise<User> => {
    await delay(200);
    const userIndex = usersStore.findIndex(u => u.id === userId);
    if (userIndex === -1) throw new Error("User not found");

    const updatedUser = { ...usersStore[userIndex], activeProfileId: profileId };
    
    usersStore[userIndex] = updatedUser;
    localStorage.setItem(STORAGE_KEYS.ALL_USERS, JSON.stringify(usersStore));
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedUser));

    return updatedUser;
  },

  // --- Marketplace & Inventory ---

  getMerchants: async (): Promise<Merchant[]> => {
    await delay(600);
    return [...merchantsStore];
  },

  getMerchantsInBounds: async (bounds: ViewportBounds): Promise<Merchant[]> => {
    await delay(400); 
    return merchantsStore.filter(m => 
      m.latitude <= bounds.north &&
      m.latitude >= bounds.south &&
      m.longitude <= bounds.east &&
      m.longitude >= bounds.west
    );
  },

  getStock: async (): Promise<any> => {
    await delay(800);
    return { status: 'ok' };
  },

  // Real Transaction simulation
  reserveStock: async (merchantId: string, productId: string, quantity: number = 1): Promise<boolean> => {
    await delay(800); // Simulate processing
    const index = merchantsStore.findIndex(m => m.id === merchantId);
    
    if (index !== -1) {
        const merchant = { ...merchantsStore[index] };
        const currentStock = merchant.stock[productId] || 0;
        
        if (currentStock >= quantity) {
            merchant.stock = {
                ...merchant.stock,
                [productId]: currentStock - quantity
            };
            merchantsStore[index] = merchant;
            
            // Persist inventory change
            localStorage.setItem(STORAGE_KEYS.MERCHANTS, JSON.stringify(merchantsStore));
            return true;
        }
    }
    return false;
  },

  // --- Dynamic Cycle Engine ---

  getCycleData: async (): Promise<CycleData> => {
    await delay(300);
    const configStr = localStorage.getItem(STORAGE_KEYS.CYCLE_CONFIG);
    
    if (configStr) {
      const config: CycleConfig = JSON.parse(configStr);
      const start = new Date(config.lastPeriodDate);
      const today = new Date();
      
      // Calculate days difference
      const diffTime = Math.abs(today.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      // Calculate current day in cycle (1-based)
      // Cycle wraps around cycleLength
      let currentDay = (diffDays % config.cycleLength);
      if (currentDay === 0) currentDay = config.cycleLength; // or 1 depending on logic, usually wrap implies day 1 is next
      // Actually, if diffDays is 0 (today is start), currentDay should be 1.
      // let's say diffDays=0 -> Day 1.
      currentDay = (diffDays % config.cycleLength) + 1;

      const phase = cycleService.calculatePhase(currentDay, config.cycleLength);
      const nextPeriodDays = config.cycleLength - currentDay + 1;

      return {
        currentDay,
        totalLength: config.cycleLength,
        phase,
        nextPeriodDays,
        startDate: config.lastPeriodDate
      };
    }

    // Default if no config
    return { ...MOCK_CYCLE_DATA, startDate: '2025-11-01' };
  },

  updateCycleConfig: async (config: CycleConfig): Promise<CycleData> => {
    await delay(500);
    localStorage.setItem(STORAGE_KEYS.CYCLE_CONFIG, JSON.stringify(config));
    return api.getCycleData();
  },

  // --- Journal Operations ---

  getJournalEntries: async (): Promise<JournalEntry[]> => {
    await delay(300);
    return [...journalStore].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  },

  addJournalEntry: async (entry: Omit<JournalEntry, 'id'>): Promise<JournalEntry> => {
    if (!navigator.onLine) {
       console.log("Offline: Queueing journal entry");
       const tempId = `temp_${Date.now()}`;
       const pendingEntry: JournalEntry = {
           ...entry,
           id: tempId,
           _pending: true
       };
       
       const queue = JSON.parse(localStorage.getItem(STORAGE_KEYS.SYNC_QUEUE) || '[]');
       queue.push({ type: 'JOURNAL_ADD', payload: pendingEntry, timestamp: Date.now() });
       localStorage.setItem(STORAGE_KEYS.SYNC_QUEUE, JSON.stringify(queue));

       journalStore.push(pendingEntry);
       localStorage.setItem(STORAGE_KEYS.JOURNAL, JSON.stringify(journalStore));
       return pendingEntry;
    }

    await delay(400);
    const newEntry: JournalEntry = {
      ...entry,
      id: `j_${Date.now()}`
    };
    journalStore.push(newEntry);
    localStorage.setItem(STORAGE_KEYS.JOURNAL, JSON.stringify(journalStore));
    return newEntry;
  }
};
