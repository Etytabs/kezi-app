import React from 'react';
import { JasminBrandIcon } from './JasminBrandIcon';

export const SplashScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-gradient-to-br from-pink-50 to-purple-100">
      <div className="animate-pulse">
        <JasminBrandIcon className="scale-150 transform transition-transform duration-1000" />
      </div>
      <h1 className="mt-8 text-3xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-600 animate-fade-in delay-200">
        Jasmin
      </h1>
      <p className="mt-2 text-purple-400 text-xs font-medium tracking-widest uppercase animate-fade-in delay-500">
        Privacy First Health
      </p>
    </div>
  );
};