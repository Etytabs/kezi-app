
import React from 'react';
import { CycleData, CyclePhase } from '../types';

interface CycleWheelProps {
  data: CycleData;
  size?: number; // Default 180 as per spec
  darkMode: boolean;
  blur: boolean;
}

export const CycleWheel: React.FC<CycleWheelProps> = ({ data, size = 180, darkMode, blur }) => {
  // A. Geometry & Canvas
  const center = size / 2; // 90
  const strokeWidth = 8;
  const radius = (size / 2) - strokeWidth; // 82
  const circumference = 2 * Math.PI * radius; // ~515.22

  // B. Progress Logic
  const progress = data.currentDay / data.totalLength;
  const dashOffset = circumference - (progress * circumference);

  // C. Knob Position Logic (Current Day)
  // -90deg offset (12 o'clock start)
  const angleInRadians = (progress * 2 * Math.PI) - (Math.PI / 2);
  const knobX = center + radius * Math.cos(angleInRadians);
  const knobY = center + radius * Math.sin(angleInRadians);

  // D. Ovulation Marker Logic (Predicted: Day 14)
  // Standard cycle logic: Ovulation is approx 14 days before next period. 
  // For a 28 day cycle, that is Day 14.
  const ovulationDay = 14; 
  const ovProgress = ovulationDay / data.totalLength;
  const ovAngle = (ovProgress * 2 * Math.PI) - (Math.PI / 2);
  const ovX = center + radius * Math.cos(ovAngle);
  const ovY = center + radius * Math.sin(ovAngle);

  // E. Phase Colors for Text/Chips
  const getPhaseColor = (phase: CyclePhase) => {
    switch (phase) {
      case CyclePhase.MENSTRUAL: return 'text-pink-600 bg-pink-50';
      case CyclePhase.OVULATION: return 'text-purple-600 bg-purple-50';
      case CyclePhase.FOLLICULAR: return 'text-teal-600 bg-teal-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };
  const phaseClass = getPhaseColor(data.phase);

  return (
    <div className={`relative flex items-center justify-center ${blur ? 'blur-sm opacity-50 grayscale' : ''}`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <defs>
          <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#F472B6" /> {/* pink-400 */}
            <stop offset="100%" stopColor="#A855F7" /> {/* purple-500 */}
          </linearGradient>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* B. The Track (Background Ring) */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          strokeWidth={strokeWidth}
          stroke="currentColor"
          fill="transparent"
          strokeLinecap="round"
          className={darkMode ? "text-white/5" : "text-gray-100"}
        />

        {/* Ovulation Indicator (Marker on Track) */}
        <circle 
          cx={ovX}
          cy={ovY}
          r={4}
          fill={darkMode ? '#2E2035' : '#FFFFFF'}
          stroke="#9333EA" // Brand Purple
          strokeWidth={2}
          className="z-10"
        />

        {/* C. The Progress Arc (Foreground Ring) */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          strokeWidth={strokeWidth}
          stroke="url(#progressGradient)"
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          strokeLinecap="round"
          transform={`rotate(-90 ${center} ${center})`}
          className="transition-all duration-1000 ease-out"
        />

        {/* D. The Indicator Knob (Current Day) */}
        {/* Pulse effect ring */}
        <circle
          cx={knobX}
          cy={knobY}
          r={10}
          fill="transparent"
          className="animate-pulse opacity-50"
          stroke="#A855F7"
          strokeWidth={1}
        />
        {/* Actual Knob: r=8.5 + 1.5 (half stroke) = 10 -> 20px Diameter */}
        <circle
          cx={knobX}
          cy={knobY}
          r={8.5}
          fill={darkMode ? '#2E2035' : '#FFFFFF'}
          stroke="#A855F7"
          strokeWidth={3}
          className="drop-shadow-md transition-all duration-1000 ease-out cursor-pointer"
        />
      </svg>
      
      {/* E. Center Content (The Data) */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
        <span className={`text-[10px] font-semibold tracking-widest uppercase mb-1 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>
          Day
        </span>
        <span className={`text-5xl font-bold font-sans -mt-2 mb-2 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
          {data.currentDay}
        </span>
        <div className={`px-2 py-0.5 rounded-full shadow-sm backdrop-blur-sm ${darkMode ? 'bg-white/10 text-white' : phaseClass}`}>
          <span className="text-[10px] font-bold uppercase tracking-wide">
            {data.phase}
          </span>
        </div>
      </div>
    </div>
  );
};
