import React from 'react';
import { Heart } from 'lucide-react';
import { MOCK_INSPIRATION } from '../constants';

interface DailyInspirationProps {
  isDarkMode: boolean;
}

export const DailyInspiration: React.FC<DailyInspirationProps> = ({ isDarkMode }) => {
  return (
    <div className="w-full">
      {/* 1. Section Header */}
      <div className="flex items-center gap-2 mb-3 px-1">
        <Heart 
          size={18} 
          className={isDarkMode ? 'text-pink-400' : 'text-pink-500'} 
          strokeWidth={2.5} 
        />
        <h3 className={`font-semibold text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
          Daily Inspiration
        </h3>
      </div>

      {/* 2. The Carousel Track */}
      {/* Negative margin/padding for bleed effect, no scrollbar, snap scrolling */}
      <div className="flex gap-3 overflow-x-auto snap-x no-scrollbar pb-4 -mx-6 px-6">
        {MOCK_INSPIRATION.map((item) => (
          <div
            key={item.id}
            className={`
              flex-shrink-0 snap-center
              min-w-[240px] max-w-[240px]
              rounded-2xl border p-4 shadow-sm
              transition-shadow hover:shadow-md cursor-default
              ${isDarkMode 
                ? 'bg-lavender-950 border-white/5' 
                : 'bg-white border-gray-100'
              }
            `}
          >
            {/* 3. Typography */}
            <h4 className={`text-sm font-bold mb-1.5 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {item.title}
            </h4>
            <p className={`text-xs italic leading-relaxed ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
              {item.body}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};