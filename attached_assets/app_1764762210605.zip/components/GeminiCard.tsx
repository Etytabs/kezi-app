import React, { useEffect, useState } from 'react';
import { Heart, Loader2, RefreshCw } from 'lucide-react';
import { InspirationContent, CyclePhase } from '../types';
import { fetchDailyInspiration } from '../services/geminiService';

interface GeminiCardProps {
  phase: CyclePhase;
}

export const GeminiCard: React.FC<GeminiCardProps> = ({ phase }) => {
  const [content, setContent] = useState<InspirationContent | null>(null);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    const data = await fetchDailyInspiration(phase);
    setContent(data);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  return (
    <div className="w-full">
      <div className="flex items-center gap-2 mb-3">
        {/* Pixel-Accurate Inspiration Heart Icon */}
        <Heart size={18} className="text-pink-500" strokeWidth={2.5} />
        <h3 className="font-bold text-gray-700">Daily Inspiration</h3>
      </div>

      <div className="glass-card rounded-2xl p-5 relative overflow-hidden group">
        {/* Background Decor */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-pink-100/50 rounded-full blur-2xl transition-all duration-700 group-hover:bg-pink-200/50"></div>
        
        {loading ? (
          <div className="flex flex-col items-center justify-center py-6 space-y-3">
            <Loader2 className="animate-spin text-pink-400 w-8 h-8" />
            <p className="text-sm text-gray-400">Consulting Jasmin AI...</p>
          </div>
        ) : (
          <div className="relative z-10 animate-fade-in">
            <h4 className="font-bold text-lg text-gray-800 mb-2">{content?.title}</h4>
            <p className="text-gray-600 italic font-serif leading-relaxed mb-4">
              "{content?.body}"
            </p>
            <div className="flex justify-between items-center">
              <span className="text-xs text-pink-400 font-semibold uppercase tracking-widest">
                {content?.source || 'Jasmin AI'}
              </span>
              <button 
                onClick={loadData}
                className="p-2 hover:bg-white/50 rounded-full transition-colors"
                title="Refresh Insight"
              >
                <RefreshCw className="w-4 h-4 text-gray-400" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};