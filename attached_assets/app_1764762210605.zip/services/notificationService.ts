
import { CyclePhase } from "../types";

export const notificationService = {
  requestPermission: async (): Promise<boolean> => {
    if (!('Notification' in window)) {
      console.warn('This browser does not support desktop notification');
      return false;
    }
    
    if (Notification.permission === 'granted') {
      return true;
    }

    const permission = await Notification.requestPermission();
    return permission === 'granted';
  },

  hasPermission: () => {
    return 'Notification' in window && Notification.permission === 'granted';
  },

  sendNotification: (title: string, options?: NotificationOptions) => {
    if (Notification.permission === 'granted') {
      try {
        // Fix: Cast options to any to allow 'vibrate' property which might be missing in some TS definitions
        const n = new Notification(title, {
          icon: 'https://cdn-icons-png.flaticon.com/512/2913/2913584.png', // Jasmin Icon
          badge: 'https://cdn-icons-png.flaticon.com/512/2913/2913584.png',
          vibrate: [200, 100, 200],
          ...options
        } as any);
        return n;
      } catch (e) {
        console.error("Notification error:", e);
      }
    }
  },

  checkFertileWindow: (phase: CyclePhase) => {
    if (!notificationService.hasPermission()) return;

    // Check if we already notified today to avoid spam (using sessionStorage for this session)
    const notifiedKey = 'jasmin_notified_fertile';
    if (sessionStorage.getItem(notifiedKey)) return;

    if (phase === CyclePhase.FOLLICULAR || phase === CyclePhase.OVULATION) {
      notificationService.sendNotification('Fertile Window Alert', {
        body: 'You are currently in your fertile window. Please take necessary precautions or actions based on your goals.',
        tag: 'fertile-window',
        requireInteraction: true
      });
      sessionStorage.setItem(notifiedKey, 'true');
    }
  },

  testNotification: () => {
    notificationService.sendNotification('Jasmin Notifications Active', {
      body: 'You will now receive alerts for your fertile window and daily pill reminders.',
    });
  }
};
