import React, { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { LandingPage } from './components/LandingPage';
import { AuthModal } from './components/AuthModal';
import { MainApp } from './components/MainApp';
import { AppState, User } from './types';
import { api } from './services/api';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>('splash');
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  useEffect(() => {
    // Phase Zero: Cold Boot Logic
    const initApp = async () => {
      // 1. Minimum Splash Duration (2.5s)
      const splashMinDuration = new Promise(resolve => setTimeout(resolve, 2500));
      
      // 2. Parallel Token Check
      const userCheck = api.getCurrentUser();

      // Wait for both
      const [_, existingUser] = await Promise.all([splashMinDuration, userCheck]);

      // Fork Logic
      if (existingUser) {
        setUser(existingUser);
        setAppState('main');
      } else {
        setAppState('landing');
      }
    };

    initApp();
  }, []);

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
    setIsAuthModalOpen(false);
    setAppState('main');
  };

  const handleLogout = async () => {
    await api.logout();
    setUser(null);
    setAppState('landing');
  };

  // State Machine Render
  return (
    <>
      {appState === 'splash' && <SplashScreen />}
      
      {appState === 'landing' && (
        <>
          <LandingPage onLoginClick={() => setIsAuthModalOpen(true)} />
          {isAuthModalOpen && (
            <AuthModal 
              onSuccess={handleLoginSuccess} 
              onClose={() => setIsAuthModalOpen(false)} 
            />
          )}
        </>
      )}

      {appState === 'main' && user && (
        <MainApp 
          user={user} 
          onLogout={handleLogout} 
          onUserUpdate={setUser}
        />
      )}
    </>
  );
};

export default App;