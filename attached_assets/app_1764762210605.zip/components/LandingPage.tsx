import React from 'react';
import { Activity, ShoppingBag, ShieldCheck } from 'lucide-react';
import { JasminBrandIcon } from './JasminBrandIcon';

interface LandingPageProps {
  onLoginClick: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onLoginClick }) => {
  return (
    <div className="min-h-screen bg-white flex flex-col relative animate-fade-in">
      {/* Hero Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 pt-12 pb-32 text-center">
        <div className="w-24 h-24 bg-pink-50 rounded-full flex items-center justify-center mb-6 animate-bounce-slow shadow-sm">
          <JasminBrandIcon className="w-12 h-12" />
        </div>
        
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-600 mb-3 tracking-tight">
          Jasmin
        </h1>
        <p className="text-lg text-gray-500 max-w-xs mx-auto mb-10 leading-relaxed">
          Your privacy-first digital health ecosystem. Connect your cycle to your care.
        </p>

        <div className="grid grid-cols-1 gap-4 w-full max-w-sm">
          <div className="p-4 rounded-2xl bg-pink-50 border border-pink-100 flex items-center gap-4 text-left">
            <div className="p-3 bg-white rounded-xl text-pink-500 shadow-sm">
              <Activity size={20} />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Smart Cycle Tracking</h3>
              <p className="text-xs text-gray-500">Private, algorithmic predictions.</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-teal-50 border border-teal-100 flex items-center gap-4 text-left">
            <div className="p-3 bg-white rounded-xl text-teal-600 shadow-sm">
              <ShoppingBag size={20} />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Health Marketplace</h3>
              <p className="text-xs text-gray-500">Access products nearby instantly.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Action Zone */}
      <div className="sticky bottom-0 bg-white/90 backdrop-blur-xl border-t border-gray-100 p-6 pb-8 z-50 animate-slide-up">
        <div className="max-w-md mx-auto space-y-3">
          <button 
            onClick={onLoginClick}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-pink-500 to-purple-500 text-white font-bold text-lg shadow-lg shadow-pink-200 hover:shadow-xl hover:shadow-pink-300 transform transition-all active:scale-98"
          >
            Sign in with Email
          </button>
          
          <button className="w-full py-4 rounded-xl bg-white border border-gray-200 text-gray-700 font-semibold flex items-center justify-center gap-2 hover:bg-gray-50 transition-colors">
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Sign in with Google
          </button>
        </div>
      </div>
    </div>
  );
};