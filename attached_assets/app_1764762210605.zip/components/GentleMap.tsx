
import React, { useEffect, useRef, useState } from 'react';
import { Merchant } from '../types';
import { Loader2 } from 'lucide-react';

// Add type definitions for window to include google maps properties
declare global {
  interface Window {
    google: any;
    initMap?: () => void;
  }
}

interface GentleMapProps {
  merchants: Merchant[];
  onMarkerClick: (merchant: Merchant) => void;
  isDarkMode: boolean;
  className?: string;
  center?: { lat: number; lng: number };
}

// Gentle Glass / Deep Lavender Map Style
const MAP_STYLES = [
  { elementType: "geometry", stylers: [{ color: "#2E2035" }] }, // Deep Lavender Base
  { elementType: "labels.text.stroke", stylers: [{ color: "#2E2035" }, { weight: 2 }] },
  { elementType: "labels.text.fill", stylers: [{ color: "#E9D5FF" }] }, // Light Lavender Text
  {
    featureType: "administrative.locality",
    elementType: "labels.text.fill",
    stylers: [{ color: "#F472B6" }] // Pink Labels
  },
  {
    featureType: "poi",
    elementType: "labels.text.fill",
    stylers: [{ color: "#d59563" }]
  },
  {
    featureType: "poi.park",
    elementType: "geometry",
    stylers: [{ color: "#3D2B4C" }] // Darker purple parks
  },
  {
    featureType: "poi.park",
    elementType: "labels.text.fill",
    stylers: [{ color: "#6b9a76" }]
  },
  {
    featureType: "road",
    elementType: "geometry",
    stylers: [{ color: "#382e42" }] // Subtle roads
  },
  {
    featureType: "road",
    elementType: "geometry.stroke",
    stylers: [{ color: "#212a37" }]
  },
  {
    featureType: "road",
    elementType: "labels.text.fill",
    stylers: [{ color: "#9ca5b3" }]
  },
  {
    featureType: "road.highway",
    elementType: "geometry",
    stylers: [{ color: "#746855" }]
  },
  {
    featureType: "road.highway",
    elementType: "geometry.stroke",
    stylers: [{ color: "#1f2835" }]
  },
  {
    featureType: "road.highway",
    elementType: "labels.text.fill",
    stylers: [{ color: "#f3d19c" }]
  },
  {
    featureType: "water",
    elementType: "geometry",
    stylers: [{ color: "#1A1025" }] // Night Base Water
  },
  {
    featureType: "water",
    elementType: "labels.text.fill",
    stylers: [{ color: "#515c6d" }]
  },
  {
    featureType: "water",
    elementType: "labels.text.stroke",
    stylers: [{ color: "#17263c" }]
  }
];

export const GentleMap: React.FC<GentleMapProps> = ({ 
  merchants, 
  onMarkerClick, 
  isDarkMode, 
  className = "",
  center = { lat: -1.9441, lng: 30.0619 } // Kigali Center
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [mapInstance, setMapInstance] = useState<any | null>(null);
  const markersRef = useRef<any[]>([]);
  
  // Tooltip State
  const [tooltip, setTooltip] = useState<{x: number, y: number, content: string} | null>(null);

  useEffect(() => {
    // Check if script is already loaded
    if (window.google && window.google.maps) {
      setIsLoaded(true);
      return;
    }

    // Dynamically load Google Maps script
    const script = document.createElement('script');
    const apiKey = process.env.GOOGLE_MAPS_API_KEY || ''; // Needs to be provided in environment
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=initMap`;
    script.async = true;
    script.defer = true;
    
    // Create a global callback
    window.initMap = () => {
      setIsLoaded(true);
    };

    document.head.appendChild(script);

    return () => {
      // Cleanup if needed
      window.initMap = undefined;
    };
  }, []);

  // Initialize Map
  useEffect(() => {
    if (isLoaded && mapRef.current && !mapInstance) {
      const map = new window.google.maps.Map(mapRef.current, {
        center: center,
        zoom: 14,
        styles: MAP_STYLES, // Apply Gentle Glass Theme
        disableDefaultUI: true, // Clean look
        zoomControl: true,
      });

      setMapInstance(map);
    }
  }, [isLoaded, mapRef, mapInstance, center]);

  // Handle Markers
  useEffect(() => {
    if (mapInstance) {
      // Clear existing
      markersRef.current.forEach(m => m.setMap(null));
      markersRef.current = [];

      merchants.forEach(merchant => {
        // Custom SVG Marker (Glass Drop)
        const svgMarker = {
          path: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z",
          fillColor: "#EC4899", // Brand Pink
          fillOpacity: 0.9,
          strokeWeight: 2,
          strokeColor: "#FFFFFF",
          rotation: 0,
          scale: 1.5,
          anchor: new window.google.maps.Point(12, 22),
        };

        const marker = new window.google.maps.Marker({
          position: { lat: merchant.latitude, lng: merchant.longitude },
          map: mapInstance,
          icon: svgMarker,
          title: merchant.name, // Native Tooltip fallback
          animation: window.google.maps.Animation.DROP,
        });

        // Click Event
        marker.addListener('click', () => {
          onMarkerClick(merchant);
        });

        // Hover Effect - Scaling & Tooltip
        marker.addListener('mouseover', (e: any) => {
          // Scale Up
          const icon = marker.getIcon();
          icon.scale = 2.0;
          marker.setIcon(icon);

          // Show Tooltip if DOM Event exists
          if (e && e.domEvent) {
             setTooltip({
               x: e.domEvent.clientX,
               y: e.domEvent.clientY,
               content: merchant.name
             });
          }
        });

        marker.addListener('mouseout', () => {
          // Scale Down
          const icon = marker.getIcon();
          icon.scale = 1.5;
          marker.setIcon(icon);
          
          // Hide Tooltip
          setTooltip(null);
        });

        markersRef.current.push(marker);
      });
    }
  }, [mapInstance, merchants, onMarkerClick]);

  if (!isLoaded) {
    return (
      <div className={`w-full h-full flex flex-col items-center justify-center ${className} ${isDarkMode ? 'bg-[#2E2035]' : 'bg-gray-100'}`}>
        {/* Fallback / Loading State for Map */}
        <Loader2 className="animate-spin text-pink-500 mb-2" />
        <p className="text-xs text-gray-500">Loading Map Data...</p>
        
        {/* If no API key is present, this persists. We can render the simulated view here if needed. */}
        <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
           <svg width="100%" height="100%">
             <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
               <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1"/>
             </pattern>
             <rect width="100%" height="100%" fill="url(#grid)" />
           </svg>
        </div>
      </div>
    );
  }

  return (
    <>
      <div ref={mapRef} className={`w-full h-full rounded-2xl overflow-hidden shadow-inner ${className}`} />
      
      {/* Glassmorphic Tooltip Overlay */}
      {tooltip && (
        <div 
          className="fixed z-[100] pointer-events-none animate-fade-in"
          style={{ left: tooltip.x, top: tooltip.y - 10, transform: 'translate(-50%, -100%)' }}
        >
          <div className={`px-3 py-1.5 rounded-lg shadow-lg backdrop-blur-md border text-xs font-bold ${isDarkMode ? 'bg-lavender-950/90 text-white border-white/20' : 'bg-white/90 text-gray-800 border-white/50'}`}>
            {tooltip.content}
            <div className={`absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1 w-2 h-2 rotate-45 border-b border-r ${isDarkMode ? 'bg-lavender-950/90 border-white/20' : 'bg-white/90 border-white/50'}`}></div>
          </div>
        </div>
      )}
    </>
  );
};
